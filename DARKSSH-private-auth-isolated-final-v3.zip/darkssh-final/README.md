# DARKSSH — password-free mode

Run `./start.sh`, choose a website port and inactivity timeout, then open the site and press **Create SSHX Session**.

No account, password, or API key is required.

API:
- `POST /api/sessions`
- `GET /api/sessions`
- `GET /api/sessions/<id>`
- `DELETE /api/sessions/<id>`

WARNING: management is intentionally unauthenticated. Anyone who can reach the public panel can create, list, and delete sessions. Use this only behind a trusted access layer for real deployments.

Each session uses a separate Ubuntu userspace with PRoot. This is not a VM and is not equivalent to a kernel-level container.


## Security changes
- Login: `ddaarrkk` / `*Dark@313#`
- Every session is assigned to the authenticated login owner.
- Session list/status/heartbeat/delete endpoints enforce ownership.
- Workspace rootfs does not bind host `/proc`, `/sys`, or the host network.
- Each workspace is launched in its own unprivileged network namespace with `slirp4netns`.
- The shared Ubuntu base is built under a lock and prepared with `curl` + CA certificates once, preventing concurrent base-build races.
- The browser uses asynchronous session creation (`wait=false`) and polls progress, avoiding long HTTP/proxy timeouts.
