#!/usr/bin/env bash
set -e
APP="$(cd "$(dirname "$0")" && pwd)"
read -r -p "Website port [4545]: " PORT
PORT="${PORT:-4545}"
read -r -p "Kill session after inactivity in minutes [15]: " IDLE
IDLE="${IDLE:-15}"
case "$PORT" in ''|*[!0-9]*) echo "Invalid port"; exit 1;; esac
case "$IDLE" in ''|*[!0-9]*) echo "Invalid timeout"; exit 1;; esac
[ "$PORT" -ge 1 ] && [ "$PORT" -le 65535 ] || exit 1
[ "$IDLE" -ge 1 ] || exit 1
mkdir -p "$APP/data/sessions" "$APP/data/images"

# The new isolation layer requires unshare + slirp4netns. Install slirp4netns
# automatically where apt is available; otherwise server.py reports the exact
# missing requirement instead of falling back to the host network.
if ! command -v slirp4netns >/dev/null 2>&1 && command -v apt-get >/dev/null 2>&1; then
  echo "[DARKSSH] Installing required private-network helper: slirp4netns"
  apt-get update -qq
  apt-get install -y slirp4netns
fi

printf '{"host":"0.0.0.0","port":%s,"idle_minutes":%s,"max_sessions":25}\n' "$PORT" "$IDLE" > "$APP/config.json"
exec python3 "$APP/server.py"
