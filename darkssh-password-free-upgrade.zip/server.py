#!/usr/bin/env python3
import json, os, re, secrets, shutil, signal, subprocess, threading, time, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

APP=Path(__file__).resolve().parent
DATA=APP/"data"; SESSIONS=DATA/"sessions"; IMAGES=DATA/"images"; BASE=DATA/"ubuntu-base"
CFG=APP/"config.json"; STATEFILE=DATA/"state.json"
for p in (SESSIONS,IMAGES): p.mkdir(parents=True,exist_ok=True)
CFGDATA=json.loads(CFG.read_text())
STATE={"sessions":{}}
try: STATE.update(json.loads(STATEFILE.read_text()))
except: pass
PROCS={}; LOCK=threading.RLock(); URLRE=re.compile(r"https://sshx\.io/s/[A-Za-z0-9_-]+")

def save():
    t=STATEFILE.with_suffix(".tmp"); t.write_text(json.dumps(STATE,indent=2)); os.replace(t,STATEFILE)
def log(x): print("[DARKSSH] "+x,flush=True)
def arch():
    return {"x86_64":"amd64","amd64":"amd64","aarch64":"arm64","arm64":"arm64","armv7l":"armhf","ppc64le":"ppc64el","riscv64":"riscv64","s390x":"s390x"}.get(os.uname().machine)
def have(x): return shutil.which(x) is not None
def ubuntu_url():
    a=arch()
    return f"https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.5-base-{a}.tar.gz" if a else None

def ensure_proot():
    if have("proot"): return True
    try:
        if have("apt-get"):
            subprocess.run(["apt-get","update","-qq"],timeout=180)
            subprocess.run(["apt-get","install","-y","proot"],timeout=180)
        elif have("apk"): subprocess.run(["apk","add","--no-cache","proot"],timeout=180)
        elif have("pkg"): subprocess.run(["pkg","install","-y","proot"],timeout=180)
    except: pass
    return have("proot")

def download(url,out):
    part=out.with_suffix(".part"); part.unlink(missing_ok=True)
    req=urllib.request.Request(url,headers={"User-Agent":"DARKSSH/1.0"})
    with urllib.request.urlopen(req,timeout=60) as r, open(part,"wb") as f:
        while True:
            b=r.read(1024*1024)
            if not b: break
            f.write(b)
    if part.stat().st_size < 1024*1024: raise RuntimeError("Ubuntu download incomplete")
    os.replace(part,out)

def ensure_base():
    if (BASE/"bin/sh").exists(): return
    u=ubuntu_url()
    if not u: raise RuntimeError("Unsupported CPU architecture: "+os.uname().machine)
    arc=IMAGES/f"ubuntu-24.04.5-{arch()}.tar.gz"
    if not arc.exists(): download(u,arc)
    if subprocess.run(["tar","-tzf",str(arc)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
        arc.unlink(missing_ok=True); raise RuntimeError("Ubuntu archive validation failed")
    tmp=DATA/"ubuntu-base.new"; shutil.rmtree(tmp,ignore_errors=True); tmp.mkdir()
    if subprocess.run(["tar","-xzf",str(arc),"-C",str(tmp)],timeout=300).returncode:
        shutil.rmtree(tmp,ignore_errors=True); raise RuntimeError("Ubuntu extraction failed")
    if not (tmp/"bin/sh").exists(): raise RuntimeError("Ubuntu rootfs incomplete")
    for p in ("proc","sys","dev","run","tmp","workspace"): (tmp/p).mkdir(parents=True,exist_ok=True)
    try: (tmp/"tmp").chmod(0o1777)
    except: pass
    try: shutil.copy2("/etc/resolv.conf",tmp/"etc/resolv.conf")
    except: pass
    (tmp/"etc/hostname").write_text("darkssh-ubuntu\n")
    (tmp/"root/.profile").write_text("export HOME=/root USER=root LOGNAME=root HOSTNAME=darkssh-ubuntu\nexport TERM=\"${TERM:-xterm-256color}\"\nexport PATH=\"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\"\nexport PS1='\\033[1;35mroot@darkssh-ubuntu\\033[0m:\\033[1;34m\\w\\033[0m# '\n")
    shutil.rmtree(BASE,ignore_errors=True); os.replace(tmp,BASE)

def pcmd(root,cmd):
    return ["proot","-0","-r",str(root),"-b","/dev:/dev","-b","/proc:/proc","-b","/sys:/sys","-b","/etc/resolv.conf:/etc/resolv.conf","-w","/root","/bin/sh","-lc",cmd]

def clone(dst):
    tmp=dst.with_name(dst.name+".new"); shutil.rmtree(tmp,ignore_errors=True); tmp.mkdir(parents=True)
    a=subprocess.Popen(["tar","-C",str(BASE),"-cf","-","."],stdout=subprocess.PIPE)
    b=subprocess.Popen(["tar","-C",str(tmp),"-xf","-"],stdin=a.stdout); a.stdout.close()
    if b.wait()!=0 or a.wait()!=0: shutil.rmtree(tmp,ignore_errors=True); raise RuntimeError("Workspace clone failed")
    os.replace(tmp,dst)

def create(name):
    with LOCK:
        active=sum(r["status"] in ("starting","running") for r in STATE["sessions"].values())
        if active>=int(CFGDATA.get("max_sessions",25)): raise RuntimeError("Maximum sessions reached")
        if not ensure_proot(): raise RuntimeError("PRoot unavailable")
        ensure_base()
        sid=secrets.token_hex(8); root=SESSIONS/sid/"rootfs"; root.parent.mkdir()
        clone(root)
        boot='export DEBIAN_FRONTEND=noninteractive; command -v curl >/dev/null || (apt-get update && apt-get install -y --no-install-recommends ca-certificates curl)'
        if subprocess.run(pcmd(root,boot),timeout=600).returncode: raise RuntimeError("Ubuntu bootstrap failed")
        rec={"id":sid,"name":(name or "workspace-"+sid[:6])[:80],"status":"starting","sshx_url":None,"created_at":time.time(),"last_activity":time.time(),"ended_at":None,"error":None}
        STATE["sessions"][sid]=rec; save()
        cmd='''set -e
export HOME=/root USER=root LOGNAME=root HOSTNAME=darkssh-ubuntu
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
if command -v sshx >/dev/null 2>&1; then sshx run
elif [ -x /usr/local/bin/sshx ]; then /usr/local/bin/sshx run
else curl -sSf https://sshx.io/get | sh -s run
fi'''
        p=subprocess.Popen(pcmd(root,cmd),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1,start_new_session=True)
        PROCS[sid]=p; rec["pid"]=p.pid; save()
        threading.Thread(target=watch,args=(sid,p),daemon=True).start()
        return rec.copy()

def watch(sid,p):
    rc=1
    try:
        for line in p.stdout:
            line=line.strip()
            if line: log(sid+": "+line)
            m=URLRE.search(line)
            if m:
                with LOCK:
                    r=STATE["sessions"].get(sid)
                    if r: r.update(status="running",sshx_url=m.group(0),last_activity=time.time()); save()
        rc=p.wait()
    except Exception as e: log(sid+": "+str(e))
    finally:
        with LOCK:
            r=STATE["sessions"].get(sid)
            if r and r["status"]!="deleted":
                r["status"]="stopped" if rc==0 else "error"; r["ended_at"]=time.time()
                if rc and not r["error"]: r["error"]=f"SSHX exited with code {rc}"
                save()
            PROCS.pop(sid,None)

def delete(sid):
    with LOCK:
        r=STATE["sessions"].get(sid)
        if not r: return False
        p=PROCS.get(sid)
        if p and p.poll() is None:
            try: os.killpg(p.pid,signal.SIGTERM)
            except: pass
            try: p.wait(5)
            except:
                try: p.kill()
                except: pass
        shutil.rmtree(SESSIONS/sid,ignore_errors=True)
        r["status"]="deleted"; r["ended_at"]=time.time(); save(); PROCS.pop(sid,None)
        return True

def public(r):
    return {k:r.get(k) for k in ("id","name","status","sshx_url","created_at","last_activity","ended_at","error")}

def janitor():
    while True:
        time.sleep(15); now=time.time(); limit=max(60,int(CFGDATA["idle_minutes"])*60)
        with LOCK: ids=[sid for sid,r in STATE["sessions"].items() if r["status"] in ("starting","running") and now-r.get("last_activity",now)>=limit]
        for sid in ids: log("Idle timeout: "+sid); delete(sid)
threading.Thread(target=janitor,daemon=True).start()

class H(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def sendj(self,c,o):
        b=json.dumps(o).encode(); self.send_response(c); self.send_header("Content-Type","application/json"); self.send_header("Cache-Control","no-store"); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b)
    def body(self):
        n=int(self.headers.get("Content-Length","0"))
        if n>65536: raise ValueError("Request too large")
        return json.loads(self.rfile.read(n) or b"{}")
    def do_GET(self):
        p=urlparse(self.path).path
        if p in ("/","/index.html"):
            b=(APP/"static/index.html").read_bytes(); self.send_response(200); self.send_header("Content-Type","text/html; charset=utf-8"); self.send_header("Content-Length",str(len(b))); self.end_headers(); self.wfile.write(b); return
        if p=="/api/health": return self.sendj(200,{"ok":True,"port":CFGDATA["port"],"ubuntu":"24.04.5","authentication":"disabled"})
        if p=="/api/sessions":
            with LOCK: return self.sendj(200,{"sessions":[public(r) for r in STATE["sessions"].values()]})
        if p.startswith("/api/sessions/"):
            sid=p.rsplit("/",1)[-1]
            with LOCK:
                r=STATE["sessions"].get(sid)
                if not r:return self.sendj(404,{"error":"session not found"})
                r["last_activity"]=time.time(); save(); return self.sendj(200,public(r))
        self.send_error(404)
    def do_POST(self):
        if urlparse(self.path).path!="/api/sessions": self.send_error(404); return
        try: d=self.body()
        except Exception as e:return self.sendj(400,{"error":str(e)})
        try:return self.sendj(202,{"ok":True,"session":public(create(str(d.get("name",""))))})
        except Exception as e:log("create: "+str(e));return self.sendj(500,{"error":str(e)})
    def do_DELETE(self):
        p=urlparse(self.path).path
        if p.startswith("/api/sessions/"):
            sid=p.rsplit("/",1)[-1]; ok=delete(sid); return self.sendj(200 if ok else 404,{"ok":ok})
        self.send_error(404)

if __name__=="__main__":
    log("Password/key authentication is DISABLED")
    log(f"Listening on {CFGDATA['host']}:{CFGDATA['port']}")
    ThreadingHTTPServer((CFGDATA["host"],int(CFGDATA["port"])),H).serve_forever()
