# DARKSSH — password-free mode

Run `./start.sh`, choose a website port and inactivity timeout, then open the site and press **Create SSHX Session**.

No account, password, or API key is required.

API:
- `POST /api/sessions`
- `GET /api/sessions`
- `GET /api/sessions/<id>`
- `DELETE /api/sessions/<id>`

WARNING: management is intentionally unauthenticated. Anyone who can reach the public panel can create, list, and delete sessions. Use this only behind a trusted access layer for real deployments.

Each session uses a separate Ubuntu userspace with PRoot. This is not a VM and is not equivalent to a kernel-level container.
