#!/usr/bin/env python3
import hashlib
import hmac
import json
import os
import re
import secrets
import shutil
import signal
import subprocess
import threading
import time
import urllib.request
import concurrent.futures
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs

APP = Path(__file__).resolve().parent
DATA = APP / "data"
SESSIONS = DATA / "sessions"
IMAGES = DATA / "images"
BASE = DATA / "ubuntu-base"
CFG = APP / "config.json"
STATEFILE = DATA / "state.json"
for p in (SESSIONS, IMAGES):
    p.mkdir(parents=True, exist_ok=True)

CFGDATA = json.loads(CFG.read_text())
STATE = {"sessions": {}}
try:
    STATE.update(json.loads(STATEFILE.read_text()))
except Exception:
    pass

# Login credentials requested for DARKSSH.
USERNAME = "ddaarrkk"
PASSWORD = "*Dark@313#"
PASSWORD_SHA256 = hashlib.sha256(PASSWORD.encode()).hexdigest()
COOKIE_NAME = "darkssh_auth"

PROCS = {}          # sid -> (workspace process, slirp process or None)
LOCK = threading.RLock()
CREATE_POOL = concurrent.futures.ThreadPoolExecutor(
    max_workers=8, thread_name_prefix="darkssh-create"
)
URLRE = re.compile(r"https://sshx\.io/s/[^\s\r\n]+")
READY_EVENTS = {}


def save():
    t = STATEFILE.with_suffix(".tmp")
    t.write_text(json.dumps(STATE, indent=2))
    os.replace(t, STATEFILE)


def log(x):
    print("[DARKSSH] " + x, flush=True)


def arch():
    return {
        "x86_64": "amd64", "amd64": "amd64", "aarch64": "arm64",
        "arm64": "arm64", "armv7l": "armhf", "ppc64le": "ppc64el",
        "riscv64": "riscv64", "s390x": "s390x"
    }.get(os.uname().machine)


def have(x):
    return shutil.which(x) is not None


def ubuntu_url():
    a = arch()
    return f"https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-24.04.5-base-{a}.tar.gz" if a else None


def ensure_proot():
    if have("proot"):
        return True
    try:
        if have("apt-get"):
            subprocess.run(["apt-get", "update", "-qq"], timeout=180)
            subprocess.run(["apt-get", "install", "-y", "proot"], timeout=180)
        elif have("apk"):
            subprocess.run(["apk", "add", "--no-cache", "proot"], timeout=180)
        elif have("pkg"):
            subprocess.run(["pkg", "install", "-y", "proot"], timeout=180)
    except Exception:
        pass
    return have("proot")


def ensure_network_tools():
    """Require a real per-session Linux network namespace plus slirp4netns.

    PRoot alone does not isolate networking. We deliberately refuse to create a
    session if the namespace cannot be created, instead of silently falling
    back to the host network.
    """
    if not have("unshare"):
        return False, "Linux unshare is unavailable"
    try:
        test = subprocess.run(["unshare", "-Urn", "true"], timeout=10,
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        if test.returncode != 0:
            return False, "Linux network namespaces are unavailable"
    except Exception as e:
        return False, "Network namespace test failed: " + str(e)

    if not have("slirp4netns"):
        try:
            if have("apt-get"):
                subprocess.run(["apt-get", "update", "-qq"], timeout=180,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                subprocess.run(["apt-get", "install", "-y", "slirp4netns"], timeout=180,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            elif have("apk"):
                subprocess.run(["apk", "add", "--no-cache", "slirp4netns"], timeout=180)
        except Exception:
            pass
    if not have("slirp4netns"):
        return False, "slirp4netns is required for private session networking"
    return True, "ok"


def download(url, out):
    part = out.with_suffix(".part")
    part.unlink(missing_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent": "DARKSSH/1.1"})
    with urllib.request.urlopen(req, timeout=60) as r, open(part, "wb") as f:
        while True:
            b = r.read(1024 * 1024)
            if not b:
                break
            f.write(b)
    if part.stat().st_size < 1024 * 1024:
        raise RuntimeError("Ubuntu download incomplete")
    os.replace(part, out)


def ensure_base():
    if (BASE / "bin/sh").exists():
        return
    u = ubuntu_url()
    if not u:
        raise RuntimeError("Unsupported CPU architecture: " + os.uname().machine)
    arc = IMAGES / f"ubuntu-24.04.5-{arch()}.tar.gz"
    if not arc.exists():
        download(u, arc)
    if subprocess.run(["tar", "-tzf", str(arc)], stdout=subprocess.DEVNULL,
                      stderr=subprocess.DEVNULL).returncode:
        arc.unlink(missing_ok=True)
        raise RuntimeError("Ubuntu archive validation failed")
    tmp = DATA / "ubuntu-base.new"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    if subprocess.run(["tar", "-xzf", str(arc), "-C", str(tmp)], timeout=300).returncode:
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError("Ubuntu extraction failed")
    if not (tmp / "bin/sh").exists():
        raise RuntimeError("Ubuntu rootfs incomplete")
    for p in ("proc", "sys", "dev", "dev/pts", "run", "tmp", "workspace"):
        (tmp / p).mkdir(parents=True, exist_ok=True)
    try:
        (tmp / "tmp").chmod(0o1777)
    except Exception:
        pass

    # The workspace network is supplied by slirp4netns. Never bind the host's
    # resolv.conf into a session.
    try:
        (tmp / "etc/resolv.conf").write_text("nameserver 10.0.2.3\n")
    except Exception:
        pass
    (tmp / "etc/hostname").write_text("darkssh-ubuntu\n")
    (tmp / "root/.profile").write_text(
        "export HOME=/root USER=root LOGNAME=root HOSTNAME=darkssh-ubuntu\n"
        "export TERM=\"${TERM:-xterm-256color}\"\n"
        "export PATH=\"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\"\n"
        "export PS1='\\033[1;35mroot@darkssh-ubuntu\\033[0m:\\033[1;34m\\w\\033[0m# '\n"
    )
    # Keep the original cached-base behavior. Individual workspaces are cloned
    # from this base and do not rebuild Ubuntu for every request.
    subprocess.run(
        pcmd(tmp, 'export DEBIAN_FRONTEND=noninteractive; command -v curl >/dev/null 2>&1 || (apt-get update -qq && apt-get install -y --no-install-recommends ca-certificates curl)'),
        timeout=600, check=True
    )
    shutil.rmtree(BASE, ignore_errors=True)
    os.replace(tmp, BASE)


def pcmd(root, cmd):
    # IMPORTANT: do not bind host /proc, /sys, /dev or host resolv.conf.
    # Host-wide /proc was the main source of cross-session process/port leaks.
    # Only a small set of device nodes needed by terminal programs are exposed.
    return [
        "proot", "-0", "-r", str(root),
        "-b", "/dev/null:/dev/null",
        "-b", "/dev/zero:/dev/zero",
        "-b", "/dev/random:/dev/random",
        "-b", "/dev/urandom:/dev/urandom",
        "-w", "/root", "/bin/sh", "-lc", cmd
    ]


def clone(dst):
    tmp = dst.with_name(dst.name + ".new")
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    a = subprocess.Popen(["tar", "-C", str(BASE), "-cf", "-", "."], stdout=subprocess.PIPE)
    b = subprocess.Popen(["tar", "-C", str(tmp), "-xf", "-"], stdin=a.stdout)
    a.stdout.close()
    if b.wait() != 0 or a.wait() != 0:
        shutil.rmtree(tmp, ignore_errors=True)
        raise RuntimeError("Workspace clone failed")
    os.replace(tmp, dst)


def password_ok(value):
    return hmac.compare_digest(hashlib.sha256(value.encode()).hexdigest(), PASSWORD_SHA256)


def token_hash(token):
    return hashlib.sha256(token.encode()).hexdigest()


def cookie_token(handler):
    raw = handler.headers.get("Cookie", "")
    for item in raw.split(";"):
        item = item.strip()
        if item.startswith(COOKIE_NAME + "="):
            return item.split("=", 1)[1]
    return ""


def owner_hash_from_request(handler):
    tok = cookie_token(handler)
    return token_hash(tok) if tok else None


def authenticated(handler):
    oh = owner_hash_from_request(handler)
    if not oh:
        return None
    # Authentication is stateless across restarts: the random token is only
    # stored as a hash on each owned session. No password is ever stored here.
    # A logged-in browser can therefore retain ownership after a backend restart.
    with LOCK:
        known = any(r.get("owner") == oh for r in STATE["sessions"].values())
    # New logins are also tracked so the panel can work before the first session.
    if known:
        return oh
    return None


# Active login tokens. Only hashes are retained.
AUTH_TOKENS = set()

def login_owner(handler, username, password):
    if not hmac.compare_digest(username, USERNAME) or not password_ok(password):
        return None
    tok = secrets.token_urlsafe(32)
    oh = token_hash(tok)
    with LOCK:
        AUTH_TOKENS.add(oh)
    return tok, oh


def is_logged_in(handler):
    oh = owner_hash_from_request(handler)
    if not oh:
        return False
    with LOCK:
        return oh in AUTH_TOKENS or any(r.get("owner") == oh for r in STATE["sessions"].values())


def require_auth(handler):
    if not is_logged_in(handler):
        handler.sendj(401, {"ok": False, "error": "Authentication required"})
        return None
    return owner_hash_from_request(handler)


def set_progress(sid, percent, stage, message=""):
    with LOCK:
        r = STATE["sessions"].get(sid)
        if r:
            r.update(progress=max(0, min(100, int(percent))), stage=stage,
                     message=message, last_activity=time.time())
            save()


def create_request(name, owner):
    with LOCK:
        active = sum(r["status"] in ("queued", "starting", "running")
                     for r in STATE["sessions"].values())
        if active >= int(CFGDATA.get("max_sessions", 25)):
            raise RuntimeError("Maximum sessions reached")
        sid = secrets.token_hex(8)
        rec = {
            "id": sid,
            "owner": owner,
            "name": (name or "workspace-" + sid[:6])[:80],
            "status": "queued", "progress": 1, "stage": "queued",
            "message": "Queued for a workspace worker", "sshx_url": None,
            "created_at": time.time(), "last_activity": time.time(),
            "ended_at": None, "error": None
        }
        STATE["sessions"][sid] = rec
        READY_EVENTS[sid] = threading.Event()
        save()
    CREATE_POOL.submit(build_session, sid)
    return rec.copy()


def build_session(sid):
    workspace_p = None
    slirp_p = None
    try:
        set_progress(sid, 5, "preparing", "Checking PRoot and private network support")
        if not ensure_proot():
            raise RuntimeError("PRoot unavailable")
        ok, reason = ensure_network_tools()
        if not ok:
            raise RuntimeError(reason)
        ensure_base()
        set_progress(sid, 15, "base-ready", "Using the shared cached Ubuntu base image")
        with LOCK:
            r = STATE["sessions"].get(sid)
            if not r:
                return
            r.update(status="starting", stage="workspace")
            save()

        root = SESSIONS / sid / "rootfs"
        root.parent.mkdir(parents=True, exist_ok=True)
        set_progress(sid, 25, "copying", "Creating isolated workspace from shared base")
        clone(root)
        set_progress(sid, 50, "bootstrap", "Ubuntu workspace ready from cached base")
        set_progress(sid, 65, "starting", "Launching private network namespace")

        cmd = """set -e
export HOME=/root USER=root LOGNAME=root HOSTNAME=darkssh-ubuntu
export PATH=\"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\"
export DARKSSH_NETWORK=private
if command -v sshx >/dev/null 2>&1; then exec sshx run
elif [ -x /usr/local/bin/sshx ]; then exec /usr/local/bin/sshx run
else curl -sSf https://sshx.io/get | sh -s run
fi"""

        # The unshare process is the root of this session's private network
        # namespace. slirp4netns then gives that namespace outbound internet
        # without putting the workspace on the host's/public network.
        workspace_p = subprocess.Popen(
            ["unshare", "-Urn", "--", "sh", "-lc", "exec " +
             " ".join(subprocess.list2cmdline([x]) for x in pcmd(root, cmd))],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
            bufsize=1, start_new_session=True
        )

        # Give the namespace a private user-mode network. The SSHX connection
        # is outbound; no public listener is created by the workspace.
        slirp_p = subprocess.Popen(
            ["slirp4netns", "--configure", "--mtu=65520", str(workspace_p.pid), "tap0"],
            stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True,
            start_new_session=True
        )
        time.sleep(0.8)
        if workspace_p.poll() is not None:
            err = ""
            if slirp_p.poll() is not None:
                try: err = (slirp_p.stderr.read() or "").strip()
                except Exception: pass
            raise RuntimeError("Private network namespace failed" + (": " + err if err else ""))

        with LOCK:
            PROCS[sid] = (workspace_p, slirp_p)
            STATE["sessions"][sid]["pid"] = workspace_p.pid
            save()
        set_progress(sid, 75, "sshx", "Private SSHX session is running; waiting for its access URL")
        threading.Thread(target=watch, args=(sid, workspace_p), daemon=True).start()
    except Exception as e:
        log(sid + ": FAILED: " + str(e))
        for p in (workspace_p, slirp_p):
            if p and p.poll() is None:
                try: p.terminate()
                except Exception: pass
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r:
                r.update(status="error", progress=100, stage="error",
                         message="Creation failed", error=str(e), ended_at=time.time())
                save()
        with LOCK:
            PROCS.pop(sid, None)


def watch(sid, p):
    rc = 1
    try:
        for line in p.stdout:
            line = line.strip()
            if line:
                log(sid + ": " + line)
            m = URLRE.search(line)
            if m:
                with LOCK:
                    r = STATE["sessions"].get(sid)
                    url = m.group(0).rstrip(".,);]")
                    if r:
                        r.update(status="running", progress=100, stage="ready",
                                 message="SSHX session is ready", sshx_url=url,
                                 last_activity=time.time())
                        save()
                ev = READY_EVENTS.get(sid)
                if ev:
                    ev.set()
        rc = p.wait()
    except Exception as e:
        log(sid + ": " + str(e))
    finally:
        with LOCK:
            r = STATE["sessions"].get(sid)
            if r and r["status"] != "deleted":
                r["status"] = "stopped" if rc == 0 else "error"
                r["ended_at"] = time.time()
                if rc and not r["error"]:
                    r["error"] = f"SSHX exited with code {rc}"
                save()
            ev = READY_EVENTS.get(sid)
            if ev:
                ev.set()
            pair = PROCS.pop(sid, None)
            if pair and pair[1] and pair[1].poll() is None:
                try: pair[1].terminate()
                except Exception: pass


def delete(sid, owner):
    with LOCK:
        r = STATE["sessions"].get(sid)
        if not r or r.get("owner") != owner:
            return False
        pair = PROCS.get(sid)
        if pair:
            wp, sp = pair
            if wp and wp.poll() is None:
                try: os.killpg(wp.pid, signal.SIGTERM)
                except Exception: pass
                try: wp.wait(5)
                except Exception:
                    try: wp.kill()
                    except Exception: pass
            if sp and sp.poll() is None:
                try: sp.terminate()
                except Exception: pass
                try: sp.wait(2)
                except Exception: pass
        shutil.rmtree(SESSIONS / sid, ignore_errors=True)
        r["status"] = "deleted"
        r["ended_at"] = time.time()
        save()
        ev = READY_EVENTS.get(sid)
        if ev:
            ev.set()
        PROCS.pop(sid, None)
        return True


def public(r):
    # Never expose owner hash, PID, filesystem path, private network details or
    # any host/process metadata.
    return {k: r.get(k) for k in (
        "id", "name", "status", "progress", "stage", "message", "sshx_url",
        "created_at", "last_activity", "ended_at", "error"
    )}


def own_sessions(owner):
    return [public(r) for r in STATE["sessions"].values() if r.get("owner") == owner]


def janitor():
    while True:
        time.sleep(15)
        now = time.time()
        limit = max(60, int(CFGDATA["idle_minutes"]) * 60)
        with LOCK:
            ids = [sid for sid, r in STATE["sessions"].items()
                   if r["status"] in ("queued", "starting", "running")
                   and now - r.get("last_activity", now) >= limit]
            # Janitor is server-side and can clean any session, but normal API
            # users can only delete their own sessions.
            for sid in ids:
                owner = STATE["sessions"][sid].get("owner")
                log("Idle timeout: " + sid)
                # release lock before delete() reacquires it
                threading.Thread(target=delete, args=(sid, owner), daemon=True).start()


threading.Thread(target=janitor, daemon=True).start()


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def sendj(self, c, o, extra_headers=None):
        b = json.dumps(o).encode()
        self.send_response(c)
        self.send_header("Content-Type", "application/json")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(b)))
        if extra_headers:
            for k, v in extra_headers:
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(b)

    def body(self):
        n = int(self.headers.get("Content-Length", "0"))
        if n > 65536:
            raise ValueError("Request too large")
        return json.loads(self.rfile.read(n) or b"{}")

    def static(self):
        b = (APP / "static/index.html").read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def cookie_headers(self, token, clear=False):
        secure = self.headers.get("X-Forwarded-Proto", "").lower() == "https"
        if clear:
            value = f"{COOKIE_NAME}=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict"
        else:
            value = f"{COOKIE_NAME}={token}; Max-Age=2592000; Path=/; HttpOnly; SameSite=Strict"
        if secure:
            value += "; Secure"
        return [("Set-Cookie", value)]

    def do_GET(self):
        p = urlparse(self.path).path
        if p in ("/", "/index.html"):
            return self.static()
        if p == "/api/health":
            return self.sendj(200, {
                "ok": True, "port": CFGDATA["port"], "ubuntu": "24.04.5",
                "authentication": "enabled", "network_isolation": "required"
            })
        if p == "/api/me":
            if not is_logged_in(self):
                return self.sendj(401, {"ok": False, "authenticated": False})
            return self.sendj(200, {"ok": True, "authenticated": True})
        if p == "/api/sessions":
            owner = require_auth(self)
            if not owner:
                return
            with LOCK:
                return self.sendj(200, {"sessions": own_sessions(owner)})
        if p.startswith("/api/sessions/"):
            owner = require_auth(self)
            if not owner:
                return
            sid = p.rsplit("/", 1)[-1]
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r or r.get("owner") != owner:
                    return self.sendj(404, {"error": "session not found"})
                return self.sendj(200, public(r))
        self.send_error(404)

    def do_POST(self):
        p = urlparse(self.path).path
        if p == "/api/login":
            try:
                d = self.body()
                result = login_owner(self, str(d.get("username", "")), str(d.get("password", "")))
                if not result:
                    return self.sendj(401, {"ok": False, "error": "Invalid username or password"})
                token, _ = result
                return self.sendj(200, {"ok": True}, self.cookie_headers(token))
            except Exception as e:
                return self.sendj(400, {"ok": False, "error": str(e)})

        if p == "/api/logout":
            oh = owner_hash_from_request(self)
            if oh:
                with LOCK:
                    AUTH_TOKENS.discard(oh)
            return self.sendj(200, {"ok": True}, self.cookie_headers("", clear=True))

        if p == "/api/sessions":
            owner = require_auth(self)
            if not owner:
                return
            try:
                d = self.body()
            except Exception as e:
                return self.sendj(400, {"error": str(e)})
            try:
                rec = create_request(str(d.get("name", "")), owner)
                query = parse_qs(urlparse(self.path).query)
                wait = query.get("wait", ["true"])[0].lower() != "false" and query.get("async", ["0"])[0] != "1"
                if not wait:
                    return self.sendj(202, {"ok": True, "ready": False, "session": public(rec)})
                ev = READY_EVENTS[rec["id"]]
                if not ev.wait(240):
                    with LOCK:
                        final = STATE["sessions"].get(rec["id"])
                    return self.sendj(504, {"ok": False, "ready": False,
                                            "error": "Timed out waiting for SSHX URL",
                                            "session": public(final) if final else rec})
                with LOCK:
                    final = STATE["sessions"].get(rec["id"])
                if not final or final.get("owner") != owner:
                    return self.sendj(404, {"ok": False, "error": "session disappeared"})
                if final.get("sshx_url"):
                    return self.sendj(200, {"ok": True, "ready": True, "session": public(final)})
                return self.sendj(502, {"ok": False, "ready": False,
                                        "error": final.get("error") or "SSHX exited before producing a URL",
                                        "session": public(final)})
            except Exception as e:
                log("create: " + str(e))
                return self.sendj(500, {"error": str(e)})

        if p.startswith("/api/sessions/") and p.endswith("/heartbeat"):
            owner = require_auth(self)
            if not owner:
                return
            sid = p.split("/")[-2]
            with LOCK:
                r = STATE["sessions"].get(sid)
                if not r or r.get("owner") != owner:
                    return self.sendj(404, {"error": "session not found"})
                r["last_activity"] = time.time()
                save()
            return self.sendj(200, {"ok": True})
        self.send_error(404)

    def do_DELETE(self):
        p = urlparse(self.path).path
        if p.startswith("/api/sessions/"):
            owner = require_auth(self)
            if not owner:
                return
            sid = p.rsplit("/", 1)[-1]
            ok = delete(sid, owner)
            return self.sendj(200 if ok else 404, {"ok": ok})
        self.send_error(404)


if __name__ == "__main__":
    log("Authentication ENABLED")
    log("Per-session network isolation ENABLED (namespace + slirp4netns required)")
    log(f"Listening on {CFGDATA['host']}:{CFGDATA['port']}")
    ThreadingHTTPServer((CFGDATA["host"], int(CFGDATA["port"])), H).serve_forever()
