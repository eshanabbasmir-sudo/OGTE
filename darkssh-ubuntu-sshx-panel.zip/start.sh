#!/usr/bin/env bash
set -u
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG="$APP_DIR/config.json"

printf '\033[1;35m'
cat <<'EOF'
╔══════════════════════════════════════════════════════╗
║             DARKSSH SESSION MANAGER                  ║
║       Ubuntu + SSHX Workspace Platform               ║
╚══════════════════════════════════════════════════════╝
EOF
printf '\033[0m\n'

read -r -p "Website port [8080]: " PORT
PORT="${PORT:-8080}"
case "$PORT" in ''|*[!0-9]*) echo "Invalid port."; exit 1;; esac
[ "$PORT" -ge 1 ] && [ "$PORT" -le 65535 ] || { echo "Port must be 1-65535."; exit 1; }

read -r -p "Kill session after inactivity in minutes [30]: " IDLE
IDLE="${IDLE:-30}"
case "$IDLE" in ''|*[!0-9]*) echo "Invalid inactivity timeout."; exit 1;; esac
[ "$IDLE" -ge 1 ] || { echo "Timeout must be at least 1 minute."; exit 1; }

PYTHON="$(command -v python3 || true)"
[ -n "$PYTHON" ] || { echo "python3 is required."; exit 1; }
command -v curl >/dev/null 2>&1 || { echo "curl is required on the host."; exit 1; }
command -v tar >/dev/null 2>&1 || { echo "tar is required on the host."; exit 1; }

mkdir -p "$APP_DIR/data/sessions" "$APP_DIR/data/images"

"$PYTHON" - "$CONFIG" "$PORT" "$IDLE" <<'PY'
import json, sys
p, port, idle = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
try:
    data=json.load(open(p))
except Exception:
    data={}
data.update({"host":"0.0.0.0","port":port,"idle_minutes":idle})
open(p,"w").write(json.dumps(data, indent=2)+"\n")
PY

echo
echo "DARKSSH listening on 0.0.0.0:$PORT"
echo "Idle timeout: ${IDLE} minutes"
echo

exec "$PYTHON" "$APP_DIR/server.py"
