# DARKSSH Ubuntu + SSHX Session Manager

A small self-hosted website/API that creates separate Ubuntu 24.04 userspace workspaces and starts one SSHX session per workspace.

## Start

```bash
chmod +x start.sh
./start.sh
```

It asks for:

1. Website port
2. Inactivity timeout in minutes

The server binds to `0.0.0.0`.

## API

The terminal prints two credentials:

- `REQUEST_API_KEY` — required for `POST /api/sessions`
- `ADMIN_API_KEY` — required for session management

Create a session:

```bash
curl -X POST http://HOST:PORT/api/sessions \
  -H 'Content-Type: application/json' \
  -H 'X-API-Key: REQUEST_API_KEY' \
  -d '{"name":"test"}'
```

List sessions:

```bash
curl http://HOST:PORT/api/sessions \
  -H 'X-Admin-Key: ADMIN_API_KEY'
```

Delete:

```bash
curl -X DELETE http://HOST:PORT/api/sessions/SESSION_ID \
  -H 'X-Admin-Key: ADMIN_API_KEY'
```

## Isolation model

Each session receives a separate copied Ubuntu Base filesystem and its own SSHX process. It uses PRoot on restricted hosts, so this does not create a VM and does not provide a separate kernel.

The inactivity timer is based on activity recorded by this manager's API. SSHX itself is a separate web terminal, so the manager cannot reliably inspect SSHX's internal browser activity. Use a conservative timeout for unattended deployments.

## Requirements

Host needs:

- bash
- python3
- curl
- tar
- PRoot (the launcher attempts to install it with apt/apk/pkg)

The first session downloads Ubuntu Base and can take some time.
