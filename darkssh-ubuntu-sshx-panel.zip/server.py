#!/usr/bin/env python3
import json, os, re, secrets, shutil, signal, subprocess, threading, time, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

APP = Path(__file__).resolve().parent
DATA = APP / "data"
SESSIONS = DATA / "sessions"
IMAGES = DATA / "images"
BASE_ROOT = DATA / "ubuntu-base"
STATE_FILE = DATA / "state.json"
CONFIG_FILE = APP / "config.json"

UBUNTU = "24.04.5"
SSHX_RE = re.compile(r"https://sshx\.io/s/[A-Za-z0-9_-]+")
LOCK = threading.RLock()
PROCS = {}

DATA.mkdir(exist_ok=True)
SESSIONS.mkdir(exist_ok=True)
IMAGES.mkdir(exist_ok=True)

def load(p, default):
    try:
        return json.loads(p.read_text())
    except Exception:
        return default

CONFIG = {"host":"0.0.0.0","port":8080,"idle_minutes":30,"max_sessions":25}
CONFIG.update(load(CONFIG_FILE, {}))
STATE = load(STATE_FILE, {"sessions":{}, "request_key":None, "admin_key":None})
STATE["request_key"] = STATE.get("request_key") or secrets.token_urlsafe(24)
STATE["admin_key"] = STATE.get("admin_key") or secrets.token_urlsafe(32)
STATE_FILE.write_text(json.dumps(STATE, indent=2))

REQUEST_KEY = STATE["request_key"]
ADMIN_KEY = STATE["admin_key"]

def save_state():
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(STATE, indent=2))
    os.replace(tmp, STATE_FILE)

def log(s):
    print("[DARKSSH] " + s, flush=True)

def host_has(x):
    return shutil.which(x) is not None

def architecture():
    return {
        "x86_64":"amd64","amd64":"amd64","aarch64":"arm64","arm64":"arm64",
        "armv7l":"armhf","armv7":"armhf","ppc64le":"ppc64el",
        "riscv64":"riscv64","s390x":"s390x"
    }.get(os.uname().machine, "")

def ubuntu_url():
    a = architecture()
    names = {
        "amd64":"amd64","arm64":"arm64","armhf":"armhf",
        "ppc64el":"ppc64el","riscv64":"riscv64","s390x":"s390x"
    }
    if a not in names:
        return None
    return f"https://cdimage.ubuntu.com/ubuntu-base/releases/24.04/release/ubuntu-base-{UBUNTU}-base-{names[a]}.tar.gz"

def ensure_proot():
    if host_has("proot"):
        return True
    try:
        if host_has("apt-get"):
            subprocess.run(["apt-get","update","-qq"], timeout=180, check=False,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            subprocess.run(["apt-get","install","-y","proot"], timeout=180, check=False,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        elif host_has("apk"):
            subprocess.run(["apk","add","--no-cache","proot"], timeout=180, check=False)
        elif host_has("pkg"):
            subprocess.run(["pkg","install","-y","proot"], timeout=180, check=False)
    except Exception:
        pass
    return host_has("proot")

def download(url, dest):
    part = dest.with_suffix(".part")
    part.unlink(missing_ok=True)
    req = urllib.request.Request(url, headers={"User-Agent":"DARKSSH/1.0"})
    with urllib.request.urlopen(req, timeout=45) as r, open(part,"wb") as f:
        while True:
            b=r.read(1024*1024)
            if not b: break
            f.write(b)
    if part.stat().st_size < 1024*1024:
        part.unlink(missing_ok=True)
        raise RuntimeError("Ubuntu archive is unexpectedly small.")
    os.replace(part, dest)

def ensure_base():
    if (BASE_ROOT/".darkssh-rootfs").exists() and (BASE_ROOT/"bin/sh").exists():
        return
    url=ubuntu_url()
    if not url:
        raise RuntimeError("Unsupported architecture: "+os.uname().machine)
    archive=IMAGES/f"ubuntu-base-{UBUNTU}-{architecture()}.tar.gz"
    if not archive.exists():
        log("Downloading Ubuntu Base for the first session...")
        download(url, archive)
    if subprocess.run(["tar","-tzf",str(archive)],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
        archive.unlink(missing_ok=True)
        raise RuntimeError("Ubuntu archive validation failed.")
    tmp=DATA/"ubuntu-base.new"
    shutil.rmtree(tmp,ignore_errors=True); tmp.mkdir()
    log("Extracting Ubuntu Base...")
    if subprocess.run(["tar","-xzf",str(archive),"-C",str(tmp)],timeout=300).returncode:
        shutil.rmtree(tmp,ignore_errors=True); raise RuntimeError("Ubuntu extraction failed.")
    if not (tmp/"bin/sh").exists():
        shutil.rmtree(tmp,ignore_errors=True); raise RuntimeError("Ubuntu rootfs is incomplete.")
    for p in ("proc","sys","dev","run","tmp","workspace"):
        (tmp/p).mkdir(parents=True,exist_ok=True)
    try: (tmp/"tmp").chmod(0o1777)
    except Exception: pass
    if Path("/etc/resolv.conf").exists():
        try: shutil.copy2("/etc/resolv.conf",tmp/"etc/resolv.conf")
        except Exception: pass
    (tmp/"etc/hostname").write_text("darkssh-ubuntu\n")
    (tmp/"etc/hosts").write_text("127.0.0.1 localhost\n127.0.1.1 darkssh-ubuntu\n::1 localhost ip6-localhost ip6-loopback\n")
    (tmp/"root").mkdir(exist_ok=True)
    (tmp/"root/.profile").write_text(
        "export HOME=/root\nexport USER=root\nexport LOGNAME=root\n"
        "export HOSTNAME=darkssh-ubuntu\nexport TERM=\"${TERM:-xterm-256color}\"\n"
        "export PATH=\"/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\"\n"
        "export PS1='\\033[1;35mroot@darkssh-ubuntu\\033[0m:\\033[1;34m\\w\\033[0m# '\n")
    (tmp/".darkssh-rootfs").write_text("Ubuntu "+UBUNTU+"\n")
    shutil.rmtree(BASE_ROOT,ignore_errors=True); os.replace(tmp,BASE_ROOT)

def clone_rootfs(dst):
    tmp=dst.with_name(dst.name+".new")
    shutil.rmtree(tmp,ignore_errors=True); tmp.mkdir(parents=True)
    p1=subprocess.Popen(["tar","-C",str(BASE_ROOT),"-cf","-","."],stdout=subprocess.PIPE)
    p2=subprocess.Popen(["tar","-C",str(tmp),"-xf","-"],stdin=p1.stdout)
    p1.stdout.close()
    if p2.wait()!=0 or p1.wait()!=0:
        shutil.rmtree(tmp,ignore_errors=True); raise RuntimeError("Workspace clone failed.")
    os.replace(tmp,dst)

def proot_cmd(root, shell):
    return ["proot","-0","-r",str(root),"-b","/dev:/dev","-b","/proc:/proc",
            "-b","/sys:/sys","-b","/etc/resolv.conf:/etc/resolv.conf",
            "-w","/root","/bin/sh","-lc",shell]

def bootstrap(root):
    r=subprocess.run(proot_cmd(root,
        'export DEBIAN_FRONTEND=noninteractive; '
        'export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"; '
        'if ! command -v curl >/dev/null 2>&1; then '
        'apt-get update && apt-get install -y --no-install-recommends ca-certificates curl; fi'),
        timeout=600)
    if r.returncode:
        raise RuntimeError("Could not install curl/CA certificates in Ubuntu.")

def make_session(name):
    with LOCK:
        active=sum(x.get("status") in ("starting","running") for x in STATE["sessions"].values())
        if active >= int(CONFIG.get("max_sessions",25)):
            raise RuntimeError("Maximum active sessions reached.")
        if not ensure_proot():
            raise RuntimeError("PRoot is unavailable on the host.")
        ensure_base()
        sid=secrets.token_hex(8)
        root=SESSIONS/sid/"rootfs"; root.parent.mkdir(parents=True)
        clone_rootfs(root); bootstrap(root)
        rec={"id":sid,"name":(name or "workspace-"+sid[:6])[:80],
             "status":"starting","sshx_url":None,"created_at":time.time(),
             "last_activity":time.time(),"ended_at":None,"pid":None,"error":None}
        STATE["sessions"][sid]=rec; save_state()
        shell=r'''set -e
export HOME=/root USER=root LOGNAME=root HOSTNAME=darkssh-ubuntu
export TERM="${TERM:-xterm-256color}"
export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
if [ -x /usr/local/bin/sshx ]; then /usr/local/bin/sshx run
elif [ -x /root/.local/bin/sshx ]; then /root/.local/bin/sshx run
else curl -sSf https://sshx.io/get | sh -s run
fi'''
        proc=subprocess.Popen(proot_cmd(root,shell),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                              text=True,bufsize=1,start_new_session=True)
        PROCS[sid]=proc; rec["pid"]=proc.pid; save_state()
        threading.Thread(target=watch,args=(sid,proc),daemon=True).start()
        return rec.copy()

def watch(sid,proc):
    rc=-1
    try:
        for line in proc.stdout:
            line=line.rstrip()
            if line: log(f"{sid}: {line}")
            m=SSHX_RE.search(line)
            if m:
                with LOCK:
                    rec=STATE["sessions"].get(sid)
                    if rec and not rec.get("sshx_url"):
                        rec["sshx_url"]=m.group(0); rec["status"]="running"
                        rec["last_activity"]=time.time(); save_state()
        rc=proc.wait()
    except Exception as e:
        log(f"{sid}: {e}")
    finally:
        with LOCK:
            rec=STATE["sessions"].get(sid)
            if rec:
                rec["status"]="stopped" if rc==0 else "error"
                rec["ended_at"]=time.time()
                if rc!=0 and not rec.get("error"): rec["error"]=f"SSHX exited with code {rc}"
                save_state()
            PROCS.pop(sid,None)

def delete_session(sid):
    with LOCK:
        rec=STATE["sessions"].get(sid)
        if not rec: return False
        p=PROCS.get(sid)
        if p and p.poll() is None:
            try: os.killpg(p.pid,signal.SIGTERM)
            except Exception:
                try: p.terminate()
                except Exception: pass
            try: p.wait(timeout=5)
            except Exception:
                try: p.kill()
                except Exception: pass
        shutil.rmtree(SESSIONS/sid,ignore_errors=True)
        rec["status"]="deleted"; rec["ended_at"]=time.time()
        save_state(); PROCS.pop(sid,None)
        return True

def cleanup():
    while True:
        time.sleep(15)
        limit=max(60,int(CONFIG.get("idle_minutes",30))*60); now=time.time()
        with LOCK:
            ids=[sid for sid,r in STATE["sessions"].items()
                 if r.get("status") in ("starting","running") and
                 now-float(r.get("last_activity",now))>=limit]
        for sid in ids:
            log("Idle timeout: "+sid); delete_session(sid)

threading.Thread(target=cleanup,daemon=True).start()

def public(r):
    return {k:r.get(k) for k in ("id","name","status","sshx_url","created_at","last_activity","ended_at","error")}

def admin(h): return secrets.compare_digest(h.headers.get("X-Admin-Key",""),ADMIN_KEY)
def request_auth(h): return secrets.compare_digest(h.headers.get("X-API-Key",""),REQUEST_KEY)

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*a): pass
    def json(self,code,obj):
        b=json.dumps(obj).encode(); self.send_response(code)
        self.send_header("Content-Type","application/json"); self.send_header("Content-Length",str(len(b)))
        self.send_header("Cache-Control","no-store"); self.end_headers(); self.wfile.write(b)
    def body(self):
        n=int(self.headers.get("Content-Length","0"))
        if n>65536: raise ValueError("Request too large")
        return json.loads(self.rfile.read(n) or b"{}")
    def file(self,name):
        p=APP/"static"/name
        if not p.exists(): self.send_error(404); return
        b=p.read_bytes(); c="text/html; charset=utf-8" if name.endswith(".html") else "text/plain"
        if name.endswith(".css"): c="text/css; charset=utf-8"
        if name.endswith(".js"): c="application/javascript; charset=utf-8"
        self.send_response(200); self.send_header("Content-Type",c); self.send_header("Content-Length",str(len(b)))
        self.end_headers(); self.wfile.write(b)
    def do_GET(self):
        p=urlparse(self.path).path
        if p in ("/","/index.html"): return self.file("index.html")
        if p=="/api/health": return self.json(200,{"ok":True,"ubuntu":UBUNTU,"port":CONFIG["port"],"idle_minutes":CONFIG["idle_minutes"]})
        if p=="/api/sessions":
            if not admin(self): return self.json(401,{"error":"admin authentication required"})
            with LOCK: return self.json(200,{"sessions":[public(r) for r in STATE["sessions"].values()]})
        if p.startswith("/api/sessions/"):
            sid=p.rsplit("/",1)[-1]
            with LOCK:
                r=STATE["sessions"].get(sid)
                if not r: return self.json(404,{"error":"session not found"})
                r["last_activity"]=time.time(); save_state()
                return self.json(200,public(r))
        self.send_error(404)
    def do_POST(self):
        p=urlparse(self.path).path
        try: d=self.body()
        except Exception as e: return self.json(400,{"error":str(e)})
        if p=="/api/sessions":
            if not request_auth(self): return self.json(401,{"error":"valid X-API-Key required"})
            try: return self.json(202,{"ok":True,"session":public(make_session(str(d.get("name",""))))})
            except Exception as e: log("create: "+str(e)); return self.json(500,{"error":str(e)})
        if p.startswith("/api/sessions/") and p.endswith("/heartbeat"):
            sid=p.split("/")[-2]
            with LOCK:
                r=STATE["sessions"].get(sid)
                if not r: return self.json(404,{"error":"session not found"})
                r["last_activity"]=time.time(); save_state()
            return self.json(200,{"ok":True})
        if p.startswith("/api/sessions/") and p.endswith("/delete"):
            if not admin(self): return self.json(401,{"error":"admin authentication required"})
            sid=p.split("/")[-2]
            ok=delete_session(sid)
            return self.json(200 if ok else 404,{"ok":ok})
        if p=="/api/admin/config":
            if not admin(self): return self.json(401,{"error":"admin authentication required"})
            with LOCK:
                if "idle_minutes" in d: CONFIG["idle_minutes"]=max(1,int(d["idle_minutes"]))
                if "max_sessions" in d: CONFIG["max_sessions"]=max(1,int(d["max_sessions"]))
                CONFIG_FILE.write_text(json.dumps(CONFIG,indent=2)+"\n")
            return self.json(200,{"ok":True,"config":CONFIG})
        self.send_error(404)
    def do_DELETE(self):
        p=urlparse(self.path).path
        if p.startswith("/api/sessions/"):
            if not admin(self): return self.json(401,{"error":"admin authentication required"})
            sid=p.rsplit("/",1)[-1]; ok=delete_session(sid)
            return self.json(200 if ok else 404,{"ok":ok})
        self.send_error(404)

def main():
    httpd=ThreadingHTTPServer((CONFIG["host"],int(CONFIG["port"])),Handler)
    log(f"Listening on {CONFIG['host']}:{CONFIG['port']}")
    log(f"REQUEST_API_KEY={REQUEST_KEY}")
    log(f"ADMIN_API_KEY={ADMIN_KEY}")
    try: httpd.serve_forever()
    except KeyboardInterrupt: pass
    finally:
        for sid in list(PROCS): delete_session(sid)
        httpd.server_close()

if __name__=="__main__": main()
