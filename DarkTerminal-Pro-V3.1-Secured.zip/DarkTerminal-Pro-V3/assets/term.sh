#!/bin/bash
# ═══════════════════════════════════════════════════════════════════════════
#  DARK TERMINAL — Personal Environment
#
#  This is a REAL shell, not a simulation - every command you type actually
#  runs. What's custom here is the identity layered on top: prompt, banner,
#  and a few extra commands, so this feels like YOUR environment rather than
#  a generic distro shell. It does not fake being a different OS/kernel
#  (e.g. we deliberately don't touch /etc/os-release) because that would risk
#  breaking real package-manager behavior that reads those files - everything
#  underneath is genuinely there and genuinely works.
#
#  This file is copied fresh into every session's own private directory - it
#  is never shared between sessions, so editing your copy never touches
#  anyone else's, and it starts brand new each time a session is created.
# ═══════════════════════════════════════════════════════════════════════════

export TERM="${TERM:-xterm-256color}"

# ── Identity ─────────────────────────────────────────────────────────────
export PS1='\[\033[01;32m\]dark@terminal\[\033[00m\]:\[\033[01;34m\]\w\[\033[00m\]\$ '
export DARK_TERMINAL=1

alias ls='ls --color=auto 2>/dev/null || ls'
alias ll='ls -lah'
alias la='ls -A'
alias cls='clear'
alias grep='grep --color=auto 2>/dev/null || grep'

# ── Banner ───────────────────────────────────────────────────────────────
dark_banner() {
  echo -e "\033[01;32m"
  cat << 'BANNER'
 ██████╗  █████╗ ██████╗ ██╗  ██╗
 ██╔══██╗██╔══██╗██╔══██╗██║ ██╔╝
 ██║  ██║███████║██████╔╝█████╔╝
 ██║  ██║██╔══██║██╔══██╗██╔═██╗
 ██████╔╝██║  ██║██║  ██║██║  ██╗
 ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝
      T E R M I N A L
BANNER
  echo -e "\033[00m"
}

# ── Custom commands ──────────────────────────────────────────────────────
sysinfo() {
  echo -e "\033[01;36mDark Terminal — Personal Environment\033[00m"
  echo "  Session ID   : ${SESSION_ID:-unknown}"
  echo "  Identity     : dark@terminal"
  echo "  Shell        : ${BASH:-/bin/bash} (${BASH_VERSION:-n/a})"
  echo "  Uptime       : $(uptime -p 2>/dev/null || echo 'n/a')"
  echo "  Kernel       : $(uname -sr 2>/dev/null || echo 'n/a')"
  echo "  Working dir  : $(pwd)"
  echo "  Isolation    : private, independent - not shared with any other session or the host"
}

about() {
  echo "Dark Terminal — your own private, isolated shell environment."
  echo "Nothing you do here is visible to, or affects, any other session or the host."
  echo "This is a real shell underneath - every command genuinely executes."
  echo "Type 'help' for the short list of custom commands."
}

help() {
  echo "Custom commands in this environment:"
  echo "  about      - what this environment is"
  echo "  sysinfo    - environment details"
  echo "  dark_banner- show the banner again"
  echo "  help       - this message"
  echo "Everything else is standard shell - ls, cd, nano, python3, whatever your"
  echo "environment has installed. This is not a restricted or simulated shell."
}

dark_banner
echo "Welcome, dark. Type 'help' to get started."
