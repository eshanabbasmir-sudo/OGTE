# DarkTerminal Pro V3.1 — Secured Edition

## What changed from V3.0

**Fixed bugs**
- The user panel was actually broken: `v3-user.js` was served as a static file but contained
  unrendered `{{ user_port }}` Jinja syntax, which is a JS syntax error — it crashed the whole
  script on load, so the "Connect" button silently did nothing. Rewritten (`static/js/user.js`)
  with no template syntax in static files; landing page now just redirects to `/t/<id>`, which
  was always the correct, working connection path.
- `terminal.html` referenced an admin-only Flask endpoint (`serve_static_admin`) from a template
  that's also rendered by the user app, which would throw when a user opened a terminal. Removed.
- The old command "security" filter compared entire raw input strings to `cd /` etc., but xterm
  sends most input character-by-character — so it almost never matched in real use. It only ever
  worked for the REST API `/write` endpoint, which does send whole lines. That's now explicit:
  `write_command()` (used by the API) checks a full line reliably; `write()` (used by the live
  keystream) can't reliably do that and now relies on the OS sandbox below instead.

**New: real admin authentication**
- `/login` on the admin panel — username `dark`, password `*Dark@313#`, secret code `141214`.
  All three are required. Passwords are hashed (never stored in plaintext beyond this file).
- 5 failed attempts locks that IP out for 15 minutes.
- Sessions persist across restarts (a secret key is generated once and saved to `.secret_key`).
- Every admin route, the admin REST API, and the admin WebSocket connection all require login.
- For curl/scripts: an `ADMIN_API_TOKEN` is generated fresh each time you start the server and
  printed once to the console. Send it as `X-API-Key: <token>` instead of logging in.

**User panel, made deliberately simple**
- No `/new`, no API links, no docs, no session list. Just a session-ID box that connects to
  `/t/<id>`. Nothing about the API or other sessions is visible from here.

**Real(er) shell isolation**
- If `firejail` or `bwrap` is installed on the host, each terminal session now actually launches
  inside it (private filesystem view, no root). The admin dashboard shows whether sandboxing is
  active. **This is the part that matters for security** — the old string-matching blocklist
  could never have stopped a determined user, because it wasn't parsing shell syntax, just
  comparing raw strings.
- If neither binary is present, sessions fall back to plain `bash` with resource limits
  (CPU/memory/process caps) but **no real filesystem isolation** — the console and admin
  dashboard both say so plainly rather than pretending otherwise. Install firejail if you want
  the isolation to be real:
  - Debian/Ubuntu: `sudo apt install firejail`
  - Termux: `pkg install firejail` (if unavailable in your Termux repo, `bwrap` via `pkg install bubblewrap` is the fallback)
- Idle sessions now auto-terminate after 6 hours (was 24h) and are checked every 5 minutes.
- Every session writes a lightweight audit log (`sessions/<id>/audit.log`) of assembled command
  lines, viewable via `/api/v2/sessions/<id>/audit` from the admin panel.

**API, cleaned up**
- Moved entirely off the user port — it only ever lived on the admin port now.
- Every admin API route now requires the session cookie or the `X-API-Key` token.
- Responses are the same shape as before but without the giant ASCII-art banner text baked
  into the JSON — the admin dashboard's **API Console** tab gives you a live, syntax-highlighted,
  readable view instead (click an endpoint, see the formatted response right there).
- Rate limiting added on session creation (10/min per IP) and user-panel connect attempts
  (30/min per IP).

**UI**
- Full redesign: new design system (`static/css/app.css` for login/landing/admin,
  `static/css/terminal.css` for the terminal window), consistent dark theme with a green/blue
  accent gradient, card-based admin dashboard with sidebar navigation (Overview / Sessions /
  Themes / API Console), live session table with kill buttons, toast notifications instead of
  inline banners, and a cleaner terminal window frame. All 8 xterm color themes are unchanged.

## Honest limitations (please read)

- I could not run this end-to-end in my sandbox — it has no network access, so `pip install
  flask-socketio` etc. isn't possible here. I verified: Python syntax compiles cleanly, all
  three JS files pass `node --check`, and the command-safety regex against a set of test cases.
  I was not able to spin up the actual Flask-SocketIO server and click through it, so please
  smoke-test on your VPS/Termux before relying on it, especially the WebSocket auth handshake.
- The command blocklist is defense-in-depth, not the security boundary — that's the sandbox
  (firejail/bwrap). Install one of them if this will ever be exposed beyond your own machine.
- "Fully secured" login covers the admin panel. The user panel is intentionally still
  no-login-by-design (session ID = capability), matching what you asked for ("simple, didn't
  add anything").

## Running

```bash
pip install -r requirements.txt
./DarkTerminal-V3.sh        # interactive port setup
# or
./start.sh                  # quick start on 8080 / 9090
```

Admin panel: `http://your-host:8080/` → log in with the credentials above.
User panel: `http://your-host:9090/` → paste a session ID created from the admin panel.

---

## V3.1.1 update — real per-session isolation + Docker

**The `cd /` → host filesystem problem is fixed at the root cause.** The previous fallback
(when firejail/bwrap weren't installed) ran plain `bash` directly on the host with only a
`$HOME` env var set — that stops nothing; `cd /` always showed the real host root.

Sessions now run, in priority order:

1. **Docker (recommended, used automatically if `docker` is installed and the daemon is running)**
   Each session is its own container:
   - Its own root filesystem — the host filesystem literally does not exist inside it, so
     `cd /` shows the container's own minimal root, not yours.
   - Its own private, non-routable IP on an isolated bridge network created automatically
     (`darkterminal-net`), with inter-container communication disabled — one session's
     container cannot reach another's, and by default cannot reach the internet or the host
     at all (`--internal`). Set `DARKTERM_ALLOW_NET=1` before starting if sessions need outbound
     internet (e.g. `apt install`) — they still get a private IP and still can't reach each
     other or the host.
   - **No published ports, ever.** All terminal I/O flows through the pty the container is
     attached to, not through the network — there's nothing to scan or connect to.
   - Only its own `sessions/<id>/home` folder is mounted in (as `/home/user`) — nothing else
     on the host is visible to it.
   - Memory/CPU/process-count capped per container.
   - Containers are named `darkterm-<id>` and force-removed on session kill or server restart.

   Install Docker on your host/VPS/Termux-proot environment, make sure the daemon is running,
   and this activates automatically — nothing to configure.

2. **firejail / bwrap** (if Docker isn't available) — namespace-level isolation, real but
   weaker than a full container; the host binaries (`/usr`, `/bin`, `/lib`) are still visible
   read-only inside bwrap's case.

3. **Plain bash** (last resort, if none of the above are installed) — **no filesystem
   isolation at all**. The admin dashboard now shows a visible warning banner when running in
   this mode so it's never silently insecure.

Check which mode is active any time: admin dashboard → Overview tab (top-right pill), or the
`isolation` field in `GET /api/v2/sessions`.

## UI update — modern, responsive, icon-based

- Replaced every emoji in the interface with a custom inline SVG icon set (sidebar nav,
  terminal window controls, buttons, alerts, toasts) — crisp at any size, no external font
  or CDN dependency, colors inherit the theme automatically.
- Admin dashboard sidebar collapses into a slide-out drawer with a hamburger toggle below
  880px width; stat cards and tables reflow for phone-sized screens down to 480px.
- Isolation status is now surfaced directly in the UI (pill on Overview, warning banner if
  running unsandboxed, per-session isolation mode on the terminal info panel).

---

## V3.1.2 update — this fixes the `cd /` problem for real, on Termux/Android too

Your screenshot showed `/root` still exposing host files (`freeroot`, `rootfs`, `ubuntu`,
`cloudflared-linux-amd64.deb`...). Root cause: **Docker and firejail/bwrap all need kernel
namespace features that non-rooted Android/Termux does not grant** — so on your actual host,
every one of the isolation tiers I shipped before silently failed and fell through to plain
bash, exactly like the original bug. The code checked whether the *binary* existed, not
whether it actually *worked* — that gap is now closed.

**What changed:**

1. **Every isolation engine is now live-tested at startup**, not just detected by binary
   presence: it actually tries to run something isolated and checks it worked before trusting
   that tier. Whichever real, working, strongest tier is found becomes the mode used —
   nothing is assumed.

2. **New tier: `proot`** — this is the one that actually works on non-rooted Termux/Android
   (it's what Termux's own official multi-distro tool is built on; no root, no namespaces
   needed). Each session gets its **own independent, full copy** of a minimal Linux
   filesystem. Nothing is shared:
   - `cd /` inside a session shows only *that session's own copy* of a root filesystem —
     never the real host.
   - Deleting everything, including files that look like system files (`rm -rf /*`), only
     ever destroys that one session's private copy. The host and every other session are
     completely untouched.
   - One-time setup: `pkg install proot && ./setup_rootfs.sh` (builds the shared *template*
     that every session then gets its own copy of — the template itself is never touched by
     a running session).

   **Honest limitation:** proot does not isolate the network — sessions share the host's
   network stack, so there is no per-session private IP in this mode (that specific guarantee
   needs real kernel namespaces, i.e. Docker on a real Linux server with root). The dashboard
   and each session's info panel say this plainly.

   Priority order now: **Docker > firejail > bwrap > proot > none (with a loud warning)**.

## UI polish

- Terminal window now fades in smoothly on load, glows subtly green once connected, and
  shows a "Establishing secure connection…" overlay with a spinner instead of a blank
  flash while the WebSocket handshake completes.
- Connection indicator dot now pulses when live.
- Session info panel shows exactly which isolation mode is protecting that specific session
  and what it does and doesn't cover.

---

## V3.1.3 update — Ubuntu rootfs + hardened proot ("no escape")

**Changed the proot template from Alpine to Ubuntu.** Run `./setup_rootfs.sh` again (delete
the old `rootfs-template/` folder first) to rebuild it — Ubuntu's official `ubuntu-base`
tarball already ships with bash, so this build is actually simpler/more reliable than the
Alpine one (no extra network-dependent install step). Set `DARKTERM_ROOTFS_DISTRO=debian`
before running the script if you want Debian instead (via debootstrap — needs
`debootstrap` installed, and is a less turnkey path than Ubuntu).

**What "no escape" means here, precisely** — please read this rather than assume:

proot is ptrace-based emulation, not a kernel-enforced security boundary the way a real
Linux namespace container (Docker, LXC) is. I cannot honestly claim it is *impossible* to
escape in the way a formally verified container boundary could claim that. What I *have*
done, which meaningfully closes the practical paths a user would actually try:

- **Every session gets its own independent, full copy** of the rootfs template — never a
  shared directory. Deleting everything inside it, including files that look like system
  files, only ever destroys that one copy.
- **`sudo` and `su` are removed** from the template, and **every setuid/setgid bit is
  stripped** from every binary in it — the standard local-privilege-escalation tools simply
  aren't there.
- **The host's real `/proc` is no longer bound in** — sessions can no longer see the host's
  process list (command lines, other users' running processes, etc). Only `/dev` is bound,
  since that's needed for basic device nodes. (Set `DARKTERM_PROOT_BIND_PROC=1` if you need
  `ps`/`top` to work inside sessions and are OK with that trade-off.)
- **The host's real hostname is no longer shown** in the prompt (it read via `\h` before,
  which leaks the real machine's hostname since proot doesn't fake `gethostname()`) — every
  session now shows a fixed `sandbox` label instead.
- **Fail-closed, not fail-open:** if proot itself can't start for any reason, the session
  now refuses to start and prints an error — it will never silently drop back to an
  unsandboxed shell the way the original bug did.

For a security boundary you can rely on with a formal guarantee (not "very hard to break",
but "the kernel enforces it"), Docker on a real VM-based VPS (not a container-based/OpenVZ
VPS) is still the right answer — check with `docker info && docker run --rm hello-world`
before assuming it's available, since many budget "container VPS" products block the
namespace creation Docker itself needs, the same way Android does.

---

## V3.1.4 update — root-run detection, faster/safer session creation

- **Root detection**: if this app is started as the real root user AND the active isolation
  is `proot` or `none`, you now get a loud warning in the console banner, a red banner in
  the admin dashboard, and a `running_as_root` field in `GET /api/v2/info`. This is not
  auto-fixable (the app can't un-root itself mid-run) — create a dedicated unprivileged
  system user and run the app as that user instead:
  ```bash
  sudo useradd -r -m -s /bin/bash darkterminal
  sudo -u darkterminal python3 darkterminal_v3.py
  ```
- **Faster session creation**: rootfs copies now try a copy-on-write clone first
  (`cp -a --reflink=auto`) — near-instant on btrfs/xfs, and still a normal fast copy
  everywhere else. Falls back automatically.
- **Race-condition fix**: concurrent requests for the same session ID during creation no
  longer risk a half-copied rootfs — each session ID has its own copy lock.

## Answers to the isolation questions asked during development (kept here for reference)

- **Does proot have root access?** Fake/emulated root only (`-0` flag) — not real root on
  the host, unless you run the whole app as real root (see the warning above; don't).
- **Can one user access another's data?** No — each session's storage is a separate host
  directory; no session's proot root ever points at another session's directory.
- **If a user deletes everything, does it affect others?** No, with one nuance that's now
  fixed: only 6 specific device files are bound in (not the whole host `/dev`), so a
  session can no longer damage shared device nodes.
- **Can a user exit proot entirely?** Not through any path I've left open, but I won't
  claim it's provably impossible — proot is ptrace-based emulation, not a kernel-enforced
  boundary. `sudo`/`su` are removed, setuid bits are stripped, `/proc` isn't bound, and
  failures are fail-closed. For a boundary with a formal guarantee, real Docker on a
  namespace-capable VPS is what actually provides that.

---

## V3.1.5 update — fixed "fork(): Resource temporarily unavailable"

If you saw errors like:
```
proot error: fork(): Resource temporarily unavailable
proot error: execve("/usr/bin/env"): Resource temporarily unavailable
```
that was a real bug in this app, not your VPS. `RLIMIT_NPROC` was set to 100 intending a
"max 100 processes per session" cap — but Linux scopes `RLIMIT_NPROC` per **real user ID**,
shared across every session this app has ever spawned under that host user, not per-session.
`proot` forks constantly for its own ptrace bookkeeping, so that shared ceiling got eaten
almost immediately. Fixed: raised to 4000 for proot (512 for firejail/bwrap/plain), with the
scoping caveat documented in the code. Docker's `--pids-limit` was never affected by this —
it's a per-container cgroup, correctly scoped already.

**If you still hit this error after updating:** your VPS/container provider likely enforces
its own external process ceiling via cgroups (common on container-based/OpenVZ-style VPS
products). The app now checks for this at startup and will print a note naming the exact
limit if it's suspiciously low — that ceiling is outside this app's control; you'd need to
ask your provider to raise it or move to a KVM/VM-based VPS plan.

---

## V3.1.6 update — dark@terminal personal environment

New: every session now boots into a distinctive `dark@terminal` branded environment instead
of a generic distro prompt — real bash underneath, nothing simulated.

- **`assets/term.sh`** is the one source of truth for this — edit it and restart the server;
  every *new* session picks up the change. Existing sessions already have their own
  independent copy (consistent with the private-per-session model) and are unaffected.
- Custom prompt: `dark@terminal:~$`
- ASCII banner on shell start
- Custom commands: `about`, `sysinfo` (shows session ID, real kernel/uptime, isolation
  mode), `help`, `dark_banner`
- **Deliberately does not fake `/etc/os-release`** or otherwise claim to be a different
  kernel/OS — that would risk breaking real package-manager behavior (`apt`, `lsb_release`,
  etc reading those files). Everything under the branding is the genuine, fully working
  underlying system.
- `.bashrc` in every session is now just `source term.sh` (or `/root/term.sh` in proot mode)
  — the actual branded-environment logic lives in one editable file, not duplicated inline
  strings scattered across the isolation-mode branches.
- `$SESSION_ID` is now exported consistently in **every** isolation mode (docker, firejail,
  bwrap, proot, plain) — previously only Docker mode set it.
