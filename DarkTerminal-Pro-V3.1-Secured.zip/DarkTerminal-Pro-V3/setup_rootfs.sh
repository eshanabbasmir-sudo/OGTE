#!/bin/bash
# DarkTerminal Pro — proot rootfs template builder (Ubuntu, hardened)
#
# Run this ONCE before starting the server if Docker/firejail/bwrap aren't available on
# your host (containerized/OpenVZ-style VPS, Termux, restricted namespaces, etc). It builds
# a single minimal Ubuntu filesystem template at ./rootfs-template — every terminal session
# then gets its own PRIVATE, INDEPENDENT COPY of this template (see darkterminal_v3.py:
# copy_rootfs_for_session), so sessions never share files with each other or with this host.
#
# Set DARKTERM_ROOTFS_DISTRO=debian to build a Debian rootfs instead (uses debootstrap;
# requires `debootstrap` to be installed and is less turnkey than the Ubuntu path below).

set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

TEMPLATE_DIR="rootfs-template"
DISTRO="${DARKTERM_ROOTFS_DISTRO:-ubuntu}"
UBUNTU_VERSION="${DARKTERM_UBUNTU_VERSION:-22.04}"
ARCH="$(uname -m)"

echo "════════════════════════════════════════════════════════"
echo "  DarkTerminal Pro — building proot rootfs template ($DISTRO)"
echo "  Architecture detected: $ARCH"
echo "════════════════════════════════════════════════════════"

if [ -d "$TEMPLATE_DIR" ] && [ -f "$TEMPLATE_DIR/bin/bash" ]; then
  echo "Template already exists at ./$TEMPLATE_DIR — remove it first if you want to rebuild:"
  echo "  rm -rf $TEMPLATE_DIR"
  exit 0
fi

if ! command -v proot &> /dev/null; then
  echo "[!] proot is not installed."
  echo "    Debian/Ubuntu VPS:  sudo apt install proot"
  echo "    Termux:             pkg install proot"
  exit 1
fi

harden_template() {
  local dir="$1"
  echo "[*] Hardening template — this is what 'no escape' actually rests on:"

  echo "    - stripping setuid/setgid bits from every binary (removes local privesc tools)"
  find "$dir" -xdev \( -perm -4000 -o -perm -2000 \) -exec chmod a-s {} + 2>/dev/null || true

  echo "    - removing sudo / su (no path to become a different/real uid inside the sandbox)"
  rm -f "$dir/usr/bin/sudo" "$dir/bin/su" "$dir/usr/bin/su" 2>/dev/null || true

  echo "    - DNS + minimal fstab so basic networking/tools behave predictably"
  mkdir -p "$dir/etc"
  { echo "nameserver 1.1.1.1"; echo "nameserver 8.8.8.8"; } > "$dir/etc/resolv.conf"

  mkdir -p "$dir/root" "$dir/dev" "$dir/proc" "$dir/tmp"
  chmod 1777 "$dir/tmp"
}

if [ "$DISTRO" = "debian" ]; then
  echo "[*] Building Debian rootfs via debootstrap (experimental path)..."
  if ! command -v debootstrap &> /dev/null; then
    echo "[!] debootstrap is required for the Debian path: sudo apt install debootstrap"
    exit 1
  fi
  mkdir -p "$TEMPLATE_DIR"
  sudo debootstrap --variant=minbase --arch="$(dpkg --print-architecture 2>/dev/null || echo amd64)" \
    bookworm "$TEMPLATE_DIR" http://deb.debian.org/debian/
  sudo chown -R "$(id -u):$(id -g)" "$TEMPLATE_DIR"
  proot -r "$TEMPLATE_DIR" -b /dev -0 /bin/sh -c "apt-get update && apt-get install -y --no-install-recommends bash" \
    || echo "[!] Couldn't confirm bash install automatically — check $TEMPLATE_DIR/bin/bash exists."
  harden_template "$TEMPLATE_DIR"

else
  # Ubuntu path: Canonical publishes official minimal "ubuntu-base" rootfs tarballs
  # specifically meant for bootstrapping containers/chroots. Bash is included by default,
  # so no extra install step (and no extra network dependency) is needed after extraction.
  case "$ARCH" in
    x86_64)          UB_ARCH="amd64" ;;
    aarch64|arm64)   UB_ARCH="arm64" ;;
    armv7l|armhf)    UB_ARCH="armhf" ;;
    *) echo "Unsupported architecture: $ARCH"
       echo "Download a matching ubuntu-base tarball manually from:"
       echo "  https://cdimage.ubuntu.com/ubuntu-base/releases/$UBUNTU_VERSION/release/"
       echo "and extract it to ./$TEMPLATE_DIR yourself, then re-run this script to harden it."
       exit 1 ;;
  esac

  TARBALL="ubuntu-base-${UBUNTU_VERSION}-base-${UB_ARCH}.tar.gz"
  BASE_URL="https://cdimage.ubuntu.com/ubuntu-base/releases/${UBUNTU_VERSION}/release"
  URL="${BASE_URL}/${TARBALL}"

  if [ ! -f "$TARBALL" ]; then
    echo "[*] Downloading $TARBALL ..."
    if command -v curl &> /dev/null; then
      curl -fL -o "$TARBALL" "$URL" || {
        echo "[!] Download failed. Check available builds at: $BASE_URL/"
        exit 1
      }
    elif command -v wget &> /dev/null; then
      wget -O "$TARBALL" "$URL" || { echo "[!] Download failed. Check: $BASE_URL/"; exit 1; }
    else
      echo "Need curl or wget to download the base rootfs. Install one and re-run."
      exit 1
    fi
  else
    echo "[*] Reusing existing $TARBALL"
  fi

  echo "[*] Extracting..."
  mkdir -p "$TEMPLATE_DIR"
  tar -xzf "$TARBALL" -C "$TEMPLATE_DIR"

  harden_template "$TEMPLATE_DIR"
fi

if [ ! -f "$TEMPLATE_DIR/bin/bash" ]; then
  echo "[!] WARNING: $TEMPLATE_DIR/bin/bash not found after build. Sessions will fail to start."
  echo "    Inspect the template manually before relying on it."
  exit 1
fi

echo ""
echo "════════════════════════════════════════════════════════"
echo "  Done. Hardened $DISTRO template ready at ./$TEMPLATE_DIR"
echo "  Restart darkterminal_v3.py — it will detect proot + this"
echo "  template automatically and use it for session isolation."
echo "════════════════════════════════════════════════════════"
