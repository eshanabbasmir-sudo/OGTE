#!/usr/bin/env python3
"""
DarkTerminal Pro V3.1 - Beast Edition (Secured)
================================================

Dual-port self-hosted web terminal.

    ADMIN_PORT (default 8080)  -> Full control panel. LOGIN REQUIRED.
    USER_PORT  (default 9090)  -> Minimal public terminal viewer. Session ID = access key.
                                   No API, no docs, no session list exposed here.

Run:
    python3 darkterminal_v3.py
    python3 darkterminal_v3.py --admin-port 8080 --user-port 9090

First run prints an ADMIN API TOKEN to the console - save it, it is only shown once
per process start and is required for programmatic (curl/API) access to the admin API.
"""

import os
import sys
import re
import json
import uuid
import secrets
import string
import hmac
import time
import shutil
import threading
import subprocess
import signal
import socket
from datetime import datetime, timedelta
from functools import wraps
from collections import deque

# Flask
from flask import (
    Flask, render_template, request, jsonify,
    send_from_directory, redirect, url_for,
    session as flask_session
)
from flask_socketio import SocketIO, emit, join_room, leave_room
from flask_cors import CORS
from werkzeug.security import generate_password_hash, check_password_hash

# System / pty
import pty
import select
import fcntl
import termios
import struct
try:
    import resource
    HAVE_RESOURCE = True
except ImportError:
    HAVE_RESOURCE = False

# ═══════════════════════════════════════════════════════════════
# PATHS / CONSTANTS
# ═══════════════════════════════════════════════════════════════

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SESSIONS_DIR = os.path.join(BASE_DIR, 'sessions')
LOGS_DIR = os.path.join(BASE_DIR, 'logs')
SECRET_KEY_FILE = os.path.join(BASE_DIR, '.secret_key')
TERM_SH_PATH = os.path.join(BASE_DIR, 'assets', 'term.sh')
os.makedirs(SESSIONS_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

def _load_term_sh():
    """The dark@terminal personal-environment script - one source of truth on disk
    (assets/term.sh), read once and written fresh into every new session's own private
    directory. Editing assets/term.sh and restarting the server changes what NEW sessions
    get; existing sessions already have their own independent copy and are unaffected."""
    try:
        with open(TERM_SH_PATH, 'r') as f:
            return f.read()
    except Exception as e:
        print(f"[term.sh] Could not load {TERM_SH_PATH}: {e} - sessions will get a minimal fallback prompt.")
        return '''#!/bin/bash
export PS1="\\[\\033[01;32m\\]dark@terminal\\[\\033[00m\\]:\\[\\033[01;34m\\]\\w\\[\\033[00m\\]\\$ "
'''

TERM_SH_CONTENT = _load_term_sh()

VERSION = "3.1.0-Beast-Secured"
API_VERSION = "2.1"

# ═══════════════════════════════════════════════════════════════
# ADMIN CREDENTIALS (hashed at startup - plaintext never stored)
# ═══════════════════════════════════════════════════════════════

ADMIN_USERNAME = "dark"
ADMIN_NAME = "DarkTech"
ADMIN_PASSWORD_HASH = generate_password_hash("*Dark@313#")
ADMIN_SECRET_CODE_HASH = generate_password_hash("141214")

# Persistent Flask secret key (so login sessions survive a restart)
if os.path.exists(SECRET_KEY_FILE):
    with open(SECRET_KEY_FILE, 'r') as f:
        FLASK_SECRET_KEY = f.read().strip()
else:
    FLASK_SECRET_KEY = secrets.token_hex(32)
    with open(SECRET_KEY_FILE, 'w') as f:
        f.write(FLASK_SECRET_KEY)
    try:
        os.chmod(SECRET_KEY_FILE, 0o600)
    except Exception:
        pass

# Token for programmatic (curl/API) access to the admin API, generated fresh every process start
ADMIN_API_TOKEN = f"dtk_{secrets.token_urlsafe(32)}"

SESSION_LIFETIME_HOURS = 8
LOGIN_MAX_ATTEMPTS = 5
LOGIN_LOCKOUT_MINUTES = 15
SESSION_IDLE_TIMEOUT_SECONDS = 6 * 3600  # auto-kill idle terminals after 6h

# ── Isolation engines ────────────────────────────────────────────
# We never assume a tool works just because its binary exists - Docker, firejail, and
# bwrap all require kernel namespace features that non-rooted Android/Termux does not
# grant to unprivileged processes. Each engine below is *actually run* once at startup;
# whichever real, working, strongest engine is found becomes ISOLATION_MODE. This is what
# stops the silent "looks sandboxed but isn't" failure mode.

DOCKER_BIN = shutil.which('docker')
DOCKER_IMAGE = os.environ.get('DARKTERM_DOCKER_IMAGE', 'debian:bookworm-slim')
DOCKER_NETWORK_NAME = os.environ.get('DARKTERM_DOCKER_NETWORK', 'darkterminal-net')
# By default containers get a private IP with NO external connectivity at all (--internal).
# Set DARKTERM_ALLOW_NET=1 if sessions need outbound internet (e.g. apt/pip) - they still
# get a private, non-public IP and still cannot reach the host or other sessions (ICC off).
DOCKER_ALLOW_NET = os.environ.get('DARKTERM_ALLOW_NET', '0') == '1'

FIREJAIL_BIN = shutil.which('firejail')
BWRAP_BIN = shutil.which('bwrap')

# proot: ptrace-based fake-chroot that needs NO root and NO kernel namespaces - this is
# the mechanism Termux's own official proot-distro tool uses, and is the one that will
# actually work on a non-rooted Android/Termux host. Each session gets its own full,
# independent COPY of a minimal root filesystem, so one session deleting everything
# (including "system" files) only ever destroys its own private copy.
PROOT_BIN = shutil.which('proot')
ROOTFS_TEMPLATE_DIR = os.environ.get('DARKTERM_ROOTFS_TEMPLATE', os.path.join(BASE_DIR, 'rootfs-template'))

def _rootfs_template_ready():
    return os.path.isdir(ROOTFS_TEMPLATE_DIR) and os.path.exists(os.path.join(ROOTFS_TEMPLATE_DIR, 'bin', 'sh'))

def _test_docker():
    if not DOCKER_BIN:
        return False
    try:
        if subprocess.run([DOCKER_BIN, 'info'], capture_output=True, timeout=5).returncode != 0:
            return False
        # Live smoke test - a daemon can respond to `info` yet still refuse to actually run
        # anything (permissions, cgroup issues, etc). Only trust it if it can really execute.
        r = subprocess.run([DOCKER_BIN, 'run', '--rm', DOCKER_IMAGE, 'true'],
                            capture_output=True, timeout=60)
        return r.returncode == 0
    except Exception:
        return False

def _test_firejail():
    if not FIREJAIL_BIN:
        return False
    try:
        r = subprocess.run([FIREJAIL_BIN, '--quiet', '--noroot', '--', 'true'],
                            capture_output=True, timeout=10)
        return r.returncode == 0
    except Exception:
        return False

def _test_bwrap():
    if not BWRAP_BIN:
        return False
    try:
        r = subprocess.run([BWRAP_BIN, '--ro-bind', '/', '/', '--unshare-all', '--', 'true'],
                            capture_output=True, timeout=10)
        return r.returncode == 0
    except Exception:
        return False

def _test_proot():
    if not PROOT_BIN or not _rootfs_template_ready():
        return False
    try:
        r = subprocess.run(
            [PROOT_BIN, '-r', ROOTFS_TEMPLATE_DIR, '/bin/sh', '-c', 'echo PROOT_ISOLATION_OK'],
            capture_output=True, timeout=10, text=True)
        return r.returncode == 0 and 'PROOT_ISOLATION_OK' in r.stdout
    except Exception:
        return False

def ensure_docker_network():
    """Create a private, isolated bridge network for terminal containers (idempotent)."""
    try:
        check = subprocess.run([DOCKER_BIN, 'network', 'inspect', DOCKER_NETWORK_NAME],
                                capture_output=True, timeout=10)
        if check.returncode != 0:
            args = [DOCKER_BIN, 'network', 'create',
                    '--opt', 'com.docker.network.bridge.enable_icc=false']
            if not DOCKER_ALLOW_NET:
                args.append('--internal')
            args.append(DOCKER_NETWORK_NAME)
            subprocess.run(args, capture_output=True, timeout=15)
            print(f"[Docker] Created isolated network '{DOCKER_NETWORK_NAME}' "
                  f"(internal={not DOCKER_ALLOW_NET}, inter-container-comm=disabled)")
    except Exception as e:
        print(f"[Docker] Network setup error: {e}")

def cleanup_stale_containers():
    """Remove any darkterm-* containers left over from a previous, uncleanly-stopped run."""
    try:
        result = subprocess.run(
            [DOCKER_BIN, 'ps', '-a', '--filter', 'name=darkterm-', '--format', '{{.Names}}'],
            capture_output=True, text=True, timeout=10)
        for name in result.stdout.splitlines():
            name = name.strip()
            if name:
                subprocess.run([DOCKER_BIN, 'rm', '-f', name], capture_output=True, timeout=10)
                print(f"[Docker] Cleaned stale container: {name}")
    except Exception as e:
        print(f"[Docker] Stale container cleanup error: {e}")

# Priority: real containers (docker) > real kernel namespaces (firejail/bwrap) > ptrace-based
# fake-root that works without any of that (proot - the Termux/Android-compatible option) > none.
print("[Isolation] Testing available engines (this only runs real commands, never assumes)...")
if _test_docker():
    ISOLATION_MODE = 'docker'
    ensure_docker_network()
    cleanup_stale_containers()
elif _test_firejail():
    ISOLATION_MODE = 'firejail'
elif _test_bwrap():
    ISOLATION_MODE = 'bwrap'
elif _test_proot():
    ISOLATION_MODE = 'proot'
elif PROOT_BIN and not _rootfs_template_ready():
    print(f"[Isolation] proot is installed but no rootfs template was found at "
          f"{ROOTFS_TEMPLATE_DIR}. Run ./setup_rootfs.sh once, then restart.")
    ISOLATION_MODE = 'none'
else:
    ISOLATION_MODE = 'none'

def _check_external_pid_limits():
    """Best-effort check for a process-count ceiling imposed by the HOST/VPS itself (via
    cgroups) - common on container-based VPS products (LXC/OpenVZ-style), independent of
    anything this app controls. If you see 'Resource temporarily unavailable' again after
    the RLIMIT_NPROC fix above, this external limit is the likely remaining cause, and the
    only fix is asking your VPS provider to raise it (or moving to a KVM/VM-based VPS)."""
    for path in ('/sys/fs/cgroup/pids.max', '/sys/fs/cgroup/pids/pids.max'):
        try:
            with open(path) as f:
                val = f.read().strip()
            if val.isdigit():
                limit = int(val)
                if limit < 500:
                    print(f"[Isolation] NOTE: this host enforces an external process limit of "
                          f"{limit} (via {path}) - set by your VPS/container provider, not by "
                          f"this app. This app's own limits cannot raise it. If sessions start "
                          f"failing with 'Resource temporarily unavailable' again even with few "
                          f"sessions open, this is likely why.")
            break
        except Exception:
            continue

_check_external_pid_limits()

print(f"[Isolation] Selected engine: {ISOLATION_MODE.upper()}")
if ISOLATION_MODE == 'proot':
    print("[Isolation] NOTE: proot isolates the filesystem fully (each session gets its own "
          "private root filesystem copy) but does NOT isolate the network - sessions share the "
          "host's network stack. For per-session private IPs, Docker on a real Linux host is required.")
elif ISOLATION_MODE == 'none':
    print("[Isolation] WARNING: no working isolation engine found. Sessions will run as plain, "
          "UNSANDBOXED shells with full access to this host's filesystem. Install Docker, "
          "firejail, bwrap, or run ./setup_rootfs.sh for proot. See README.md.")

# ── Root-run detection ───────────────────────────────────────────
# proot has no seccomp filtering and does not drop Linux capabilities - it only intercepts
# syscalls to fake path translation. If this whole app is started as the real root user,
# an escape from proot's emulation (not something we can rule out with certainty - see
# README) hands over real root, not a limited account. This is the single biggest lever
# an operator controls, so we check for it and warn loudly rather than staying silent.
RUNNING_AS_ROOT = hasattr(os, 'geteuid') and os.geteuid() == 0
if RUNNING_AS_ROOT and ISOLATION_MODE in ('proot', 'none'):
    print("=" * 70)
    print("[SECURITY WARNING] This server is running as the REAL root user, and the active")
    print(f"isolation mode is '{ISOLATION_MODE}', which does not use kernel namespaces.")
    print("If a session ever escaped its sandbox, it would inherit REAL root on this host.")
    print("Strongly recommended: create a dedicated unprivileged user and run this app as")
    print("that user instead (see README.md).")
    print("=" * 70)

# ── Rootfs copy locking + fast-copy ──────────────────────────────
_rootfs_copy_locks = {}
_rootfs_copy_locks_guard = threading.Lock()

def _get_rootfs_lock(session_id):
    with _rootfs_copy_locks_guard:
        lock = _rootfs_copy_locks.get(session_id)
        if lock is None:
            lock = threading.Lock()
            _rootfs_copy_locks[session_id] = lock
        return lock

def _fast_copy_tree(src, dst):
    """Copy-on-write clone if the filesystem supports it (btrfs/xfs/apfs - near-instant,
    no extra disk used until a session actually writes to a file), otherwise a normal
    full copy. Either way the result is a fully independent, private directory."""
    try:
        r = subprocess.run(['cp', '-a', '--reflink=auto', src, dst],
                            capture_output=True, timeout=60)
        if r.returncode == 0 and os.path.isdir(dst):
            return
    except Exception:
        pass
    if os.path.isdir(dst):
        shutil.rmtree(dst, ignore_errors=True)
    shutil.copytree(src, dst, symlinks=True)

def copy_rootfs_for_session(session_id, storage_path):
    """Give this session its own independent, full copy of the rootfs template. Nothing here
    is shared with any other session or the host - deleting everything inside it, including
    files that look like 'system' files, only ever destroys this one copy."""
    session_rootfs = os.path.join(storage_path, 'rootfs')
    with _get_rootfs_lock(session_id):
        if not os.path.isdir(session_rootfs) or not os.path.exists(os.path.join(session_rootfs, 'bin')):
            _fast_copy_tree(ROOTFS_TEMPLATE_DIR, session_rootfs)
            for d in ('dev', 'proc', 'tmp', 'root'):
                os.makedirs(os.path.join(session_rootfs, d), exist_ok=True)
            # Placeholder files for proot to bind the specific host device nodes onto (see
            # start()) - a bind target must already exist. These are plain empty files until
            # proot binds the real device over them at session start; they are NOT the shared
            # host /dev directory itself, so nothing here can be used to tamper with it.
            dev_dir = os.path.join(session_rootfs, 'dev')
            for node in ('null', 'zero', 'random', 'urandom', 'tty', 'full'):
                node_path = os.path.join(dev_dir, node)
                if not os.path.exists(node_path):
                    open(node_path, 'a').close()
    term_sh_path = os.path.join(session_rootfs, 'root', 'term.sh')
    with open(term_sh_path, 'w') as f:
        f.write(TERM_SH_CONTENT)
    bashrc_path = os.path.join(session_rootfs, 'root', '.bashrc')
    with open(bashrc_path, 'w') as f:
        f.write('#!/bin/bash\nsource /root/term.sh\n')
    return session_rootfs

# ═══════════════════════════════════════════════════════════════
# THEMES
# ═══════════════════════════════════════════════════════════════

THEMES = {
    "dark": {"name": "Dark (Default)", "background": "#0a0a0f", "foreground": "#00ff88", "cursor": "#00ff88",
              "selection": "rgba(0, 255, 136, 0.3)", "black": "#000000", "red": "#ff5f57", "green": "#28c840",
              "yellow": "#febc2e", "blue": "#5c9eff", "magenta": "#bf55c4", "cyan": "#00d5e8", "white": "#ffffff",
              "brightBlack": "#666680", "brightRed": "#ff7b75", "brightGreen": "#50fa7b", "brightYellow": "#f1fa8c",
              "brightBlue": "#82bfff", "brightMagenta": "#d57de8", "brightCyan": "#6be5e8", "brightWhite": "#ffffff"},
    "matrix": {"name": "Matrix Rain", "background": "#000000", "foreground": "#00ff41", "cursor": "#00ff41",
               "selection": "rgba(0, 255, 65, 0.3)", "black": "#000000", "red": "#ff0000", "green": "#00ff41",
               "yellow": "#ffff00", "blue": "#0000ff", "magenta": "#ff00ff", "cyan": "#00ffff", "white": "#ffffff",
               "brightBlack": "#333333", "brightRed": "#ff3333", "brightGreen": "#33ff33", "brightYellow": "#ffff33",
               "brightBlue": "#3333ff", "brightMagenta": "#ff33ff", "brightCyan": "#33ffff", "brightWhite": "#ffffff"},
    "cyberpunk": {"name": "Cyberpunk Neon", "background": "#1a0a2e", "foreground": "#f0abfc", "cursor": "#f0abfc",
                  "selection": "rgba(240, 171, 252, 0.3)", "black": "#0d0015", "red": "#ff006e", "green": "#06ffa5",
                  "yellow": "#ffbe0b", "blue": "#3a86ff", "magenta": "#8338ec", "cyan": "#00f5ff", "white": "#ffffff",
                  "brightBlack": "#330036", "brightRed": "#ff3388", "brightGreen": "#33ff77", "brightYellow": "#ffcc33",
                  "brightBlue": "#66aaff", "brightMagenta": "#9955ee", "brightCyan": "#33ffff", "brightWhite": "#ffffff"},
    "hacker": {"name": "Hacker Green", "background": "#0c0c0c", "foreground": "#0f0", "cursor": "#0f0",
               "selection": "rgba(0, 255, 0, 0.3)", "black": "#000", "red": "#f00", "green": "#0f0", "yellow": "#ff0",
               "blue": "#00f", "magenta": "#f0f", "cyan": "#0ff", "white": "#fff", "brightBlack": "#333",
               "brightRed": "#f55", "brightGreen": "#5f5", "brightYellow": "#ff5", "brightBlue": "#55f",
               "brightMagenta": "#f5f", "brightCyan": "#5ff", "brightWhite": "#fff"},
    "ocean": {"name": "Deep Ocean", "background": "#0a1628", "foreground": "#00d4ff", "cursor": "#00d4ff",
              "selection": "rgba(0, 212, 255, 0.3)", "black": "#05101f", "red": "#ff6b6b", "green": "#4ecdc4",
              "yellow": "#ffe66d", "blue": "#45b7d1", "magenta": "#a855f7", "cyan": "#00d4ff", "white": "#f8f9fa",
              "brightBlack": "#1a2744", "brightRed": "#ff8888", "brightGreen": "#6eeee6", "brightYellow": "#fff088",
              "brightBlue": "#68ccff", "brightMagenta": "#c77dff", "brightCyan": "#44ddff", "brightWhite": "#ffffff"},
    "solarized": {"name": "Solarized Dark", "background": "#002b36", "foreground": "#839496", "cursor": "#839496",
                  "selection": "rgba(131, 148, 150, 0.3)", "black": "#073642", "red": "#dc322f", "green": "#859900",
                  "yellow": "#b58900", "blue": "#268bd2", "magenta": "#d33682", "cyan": "#2aa198", "white": "#eee8d5",
                  "brightBlack": "#002b36", "brightRed": "#cb4b16", "brightGreen": "#586e75", "brightYellow": "#657b83",
                  "brightBlue": "#839496", "brightMagenta": "#6c71c4", "brightCyan": "#93a1a1", "brightWhite": "#fdf6e3"},
    "monokai": {"name": "Monokai Pro", "background": "#272822", "foreground": "#f8f8f2", "cursor": "#f8f8f2",
                "selection": "rgba(248, 248, 242, 0.3)", "black": "#272822", "red": "#f92672", "green": "#a6e22e",
                "yellow": "#f4bf75", "blue": "#66d9ef", "magenta": "#ae81ff", "cyan": "#a1efe4", "white": "#f8f8f2",
                "brightBlack": "#75715e", "brightRed": "#f92672", "brightGreen": "#a6e22e", "brightYellow": "#e6db74",
                "brightBlue": "#66d9ef", "brightMagenta": "#ae81ff", "brightCyan": "#a1efe4", "brightWhite": "#f9f8f5"},
    "nord": {"name": "Nord", "background": "#2e3440", "foreground": "#eceff4", "cursor": "#eceff4",
             "selection": "rgba(236, 239, 244, 0.2)", "black": "#3b4252", "red": "#bf616a", "green": "#a3be8c",
             "yellow": "#ebcb8b", "blue": "#81a1c1", "magenta": "#b48ead", "cyan": "#88c0d0", "white": "#e5e9f0",
             "brightBlack": "#4c566a", "brightRed": "#bf616a", "brightGreen": "#a3be8c", "brightYellow": "#ebcb8b",
             "brightBlue": "#81a1c1", "brightMagenta": "#b48ead", "brightCyan": "#8fbcbb", "brightWhite": "#eceff4"}
}

# ═══════════════════════════════════════════════════════════════
# FLASK APPS (dual instance for dual port)
# ═══════════════════════════════════════════════════════════════

def create_app(name):
    app = Flask(name, static_folder='static', template_folder='templates')
    app.config['SECRET_KEY'] = FLASK_SECRET_KEY
    app.config['SESSIONS_DIR'] = SESSIONS_DIR
    app.config['MAX_SESSIONS'] = 100
    app.config['JSON_SORT_KEYS'] = False
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    app.permanent_session_lifetime = timedelta(hours=SESSION_LIFETIME_HOURS)
    return app

admin_app = create_app('AdminApp')
user_app = create_app('UserApp')

# Admin app: no open CORS (it holds authenticated cookies / the API token)
CORS(admin_app, supports_credentials=True)
# User app: relaxed, it holds no secrets - session id itself is the only credential
CORS(user_app)

admin_socketio = SocketIO(admin_app, cors_allowed_origins="*", async_mode='threading', manage_session=True)
user_socketio = SocketIO(user_app, cors_allowed_origins="*", async_mode='threading', manage_session=False)

# ═══════════════════════════════════════════════════════════════
# SHARED STATE
# ═══════════════════════════════════════════════════════════════

active_sessions = {}
session_lock = threading.Lock()

login_attempts = {}   # ip -> [timestamps of failed attempts]
login_lock_until = {}  # ip -> datetime until which login is locked
rate_state = {}        # ip -> [timestamps] generic rate limiter
rate_lock = threading.Lock()

ADMIN_PORT = 8080
USER_PORT = 9090
HOST = '0.0.0.0'

# ═══════════════════════════════════════════════════════════════
# HELPERS
# ═══════════════════════════════════════════════════════════════

def get_base_url(request_obj):
    url = request_obj.url_root.rstrip('/')
    forwarded_host = request_obj.headers.get('X-Forwarded-Host')
    forwarded_proto = request_obj.headers.get('X-Forwarded-Proto', 'http')
    host_header = request_obj.headers.get('Host')
    if forwarded_host:
        clean_host = forwarded_host.split(':')[0] if ':443' in forwarded_host or ':80' in forwarded_host else forwarded_host
        url = f"{forwarded_proto}://{clean_host}"
    elif host_header and ('cloudflare' in host_header or 'trycloudflare' in str(url)):
        url = f"{request_obj.scheme or 'https'}://{host_header}".rstrip('/')
    return url.rstrip('/')

def get_client_ip(request_obj):
    if x_forwarded_for := request_obj.headers.get('X-Forwarded-For'):
        return x_forwarded_for.split(',')[0].strip()
    if x_real_ip := request_obj.headers.get('X-Real-IP'):
        return x_real_ip
    return request_obj.remote_addr or 'unknown'

def generate_session_id(length=32):
    alphabet = string.ascii_uppercase + string.ascii_lowercase + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def is_rate_limited(key, max_calls=20, window_seconds=60):
    """Generic sliding-window rate limiter."""
    now = time.time()
    with rate_lock:
        calls = rate_state.setdefault(key, [])
        calls[:] = [t for t in calls if now - t < window_seconds]
        if len(calls) >= max_calls:
            return True
        calls.append(now)
        return False

def create_private_storage(session_id):
    """Every session gets its own directory tree under SESSIONS_DIR, never shared with
    any other session. `home` is the only part ever mounted into a session's shell/container -
    `tmp`, `data`, `downloads` are host-side bookkeeping and are never exposed to the shell."""
    storage_path = os.path.join(SESSIONS_DIR, session_id)
    os.makedirs(storage_path, exist_ok=True)
    for subdir in ['home', 'tmp', 'data', 'downloads']:
        os.makedirs(os.path.join(storage_path, subdir), exist_ok=True)
    home_path = os.path.join(storage_path, 'home')
    # NOTE: HOME here is intentionally NOT the host path - inside a Docker session this
    # file lives at /home/user/term.sh (its only view of the world); on the non-Docker
    # fallback paths bash is pointed at this same file via an absolute host path.
    with open(os.path.join(home_path, 'term.sh'), 'w') as f:
        f.write(TERM_SH_CONTENT)
    # .bashrc just sources the real, editable term.sh - keeps the branded-environment
    # logic in one file (assets/term.sh) instead of duplicated inline strings.
    with open(os.path.join(home_path, '.bashrc'), 'w') as f:
        f.write('#!/bin/bash\nsource "$(dirname "${BASH_SOURCE[0]}")/term.sh"\n')
    return storage_path

# ═══════════════════════════════════════════════════════════════
# COMMAND SAFETY (defense-in-depth, not a substitute for the OS sandbox below)
# ═══════════════════════════════════════════════════════════════

DANGEROUS_PATTERNS = [
    r'\bsudo\b', r'\bsu\s+-', r'\bmkfs\b', r'\bdd\s+if=', r'\b(shutdown|reboot|halt|poweroff)\b',
    r'\biptables\b', r'\buseradd\b', r'\buserdel\b', r'\bgroupadd\b', r'\bchpasswd\b', r'\bpasswd\s+root\b',
    r'rm\s+-[a-zA-Z]*r[a-zA-Z]*f?[a-zA-Z]*\s+/(\s|$)', r':\(\)\s*\{\s*:\s*\|\s*:\s*&\s*\}\s*;\s*:',
    r'>\s*/dev/(sd|nvme|hd)', r'\bchmod\s+-R\s+777\s+/(\s|$)', r'\bchown\s+-R\s+\S+\s+/(\s|$)',
    r'^\s*cd\s+/\s*$', r'^\s*cd\s+/(bin|etc|root|boot|dev|proc|sys|lib|usr|var|sbin)(\s|/|$)',
]
DANGEROUS_RE = re.compile('|'.join(DANGEROUS_PATTERNS))

def is_dangerous_line(line):
    """Checks a *complete* command line (as sent by the REST API) against the blocklist."""
    if DANGEROUS_RE.search(line.strip()):
        return True
    fragments = re.split(r'&&|\|\||;|\|', line)
    for frag in fragments:
        if DANGEROUS_RE.search(frag.strip()):
            return True
    return False

# ═══════════════════════════════════════════════════════════════
# TERMINAL SESSION
# ═══════════════════════════════════════════════════════════════

class TerminalSession:
    def __init__(self, session_id, theme="dark", created_by="admin", owner_ip="unknown"):
        self.session_id = session_id
        self.theme = theme
        self.created_by = created_by
        self.owner_ip = owner_ip
        self.pid = None
        self.fd = None
        self.storage_path = create_private_storage(session_id)
        self.created_at = datetime.now()
        self.last_activity = datetime.now()
        self.is_active = False
        self.isolation_mode = ISOLATION_MODE
        self.container_name = f"darkterm-{session_id[:16]}"
        self.output_buffer = deque(maxlen=5000)
        self.buffer_lock = threading.Lock()
        self.connected_clients = set()
        self.stats = {'commands_executed': 0, 'bytes_transferred': 0}
        self._line_acc = ''  # accumulates a line client-side for lightweight audit logging

    def _audit(self, line):
        try:
            with open(os.path.join(self.storage_path, 'audit.log'), 'a') as f:
                f.write(f"[{datetime.now().isoformat()}] {line}\n")
        except Exception:
            pass

    def start(self):
        if self.is_active:
            return True
        try:
            session_rootfs = None
            if self.isolation_mode == 'proot':
                # Do the (possibly slow) filesystem copy in the parent, before forking -
                # never do heavy work in a freshly-forked pty child.
                session_rootfs = copy_rootfs_for_session(self.session_id, self.storage_path)

            self.pid, self.fd = pty.fork()

            if self.pid == 0:
                # ── Child process ──
                os.environ['TERM'] = 'xterm-256color'
                home_dir = os.path.join(self.storage_path, 'home')
                rcfile = os.path.join(home_dir, '.bashrc')
                bash_argv = ['bash', '--rcfile', rcfile, '-i'] if os.path.isfile(rcfile) else ['bash', '-i']

                # Real resource caps (defense-in-depth even inside a container).
                # NOTE on RLIMIT_NPROC: Linux scopes this per REAL UID, not per-process-tree -
                # it is a ceiling shared across every session this app has ever spawned under
                # this same host user, not a per-session cap. Setting it too low here was a
                # real bug: proot itself forks constantly for its own ptrace bookkeeping (every
                # command run inside the sandbox costs proot extra forks), so a shared 100-
                # process ceiling across the whole app got exhausted almost immediately and
                # produced exactly "fork(): Resource temporarily unavailable" / "execve(...):
                # Resource temporarily unavailable". Docker's --pids-limit is unaffected by this
                # since it's a per-container cgroup, correctly scoped - this only ever hit the
                # proot/firejail/bwrap/plain-bash paths. Set high enough to give proot headroom;
                # this is still a real safety net against a genuine fork-bomb, just not a tight
                # per-session cap (that would require running each session under its own Linux
                # UID, which this app does not do).
                if HAVE_RESOURCE:
                    try:
                        nproc_cap = 4000 if self.isolation_mode == 'proot' else 512
                        resource.setrlimit(resource.RLIMIT_NPROC, (nproc_cap, nproc_cap))
                        resource.setrlimit(resource.RLIMIT_CPU, (7200, 7200))
                        resource.setrlimit(resource.RLIMIT_AS, (1536 * 1024 * 1024, 1536 * 1024 * 1024))
                        resource.setrlimit(resource.RLIMIT_FSIZE, (512 * 1024 * 1024, 512 * 1024 * 1024))
                    except Exception:
                        pass

                if self.isolation_mode == 'docker':
                    # Full container: own root filesystem (host is invisible), own private
                    # non-routable IP on an isolated network, zero published ports - all I/O
                    # goes through this pty, never through the network.
                    docker_args = [
                        DOCKER_BIN, 'run', '--rm', '-i', '-t',
                        '--name', self.container_name,
                        '--hostname', 'darkterminal',
                        '--network', DOCKER_NETWORK_NAME,
                        '--memory', '512m', '--cpus', '1', '--pids-limit', '150',
                        '--cap-drop', 'ALL', '--security-opt', 'no-new-privileges',
                        '-v', f'{home_dir}:/home/user',
                        '-w', '/home/user',
                        '-e', 'TERM=xterm-256color',
                        '-e', f'SESSION_ID={self.session_id}',
                        DOCKER_IMAGE,
                        '/bin/bash', '--rcfile', '/home/user/.bashrc', '-i'
                    ]
                    os.execvp(DOCKER_BIN, docker_args)
                elif self.isolation_mode == 'firejail':
                    os.environ['HOME'] = home_dir
                    os.environ['SESSION_ID'] = self.session_id
                    os.chdir(home_dir)
                    argv = ['firejail', '--quiet', '--noroot', f'--private={home_dir}', '/bin/bash'] + bash_argv[1:]
                    os.execvp(FIREJAIL_BIN, argv)
                elif self.isolation_mode == 'bwrap':
                    os.environ['HOME'] = home_dir
                    os.environ['SESSION_ID'] = self.session_id
                    os.chdir(home_dir)
                    argv = [
                        'bwrap', '--ro-bind', '/usr', '/usr', '--ro-bind', '/bin', '/bin',
                        '--ro-bind', '/lib', '/lib', '--ro-bind-try', '/lib64', '/lib64',
                        '--ro-bind', '/etc/resolv.conf', '/etc/resolv.conf',
                        '--bind', home_dir, home_dir, '--proc', '/proc', '--dev', '/dev',
                        '--chdir', home_dir, '--die-with-parent', '/bin/bash'
                    ] + bash_argv[1:]
                    os.execvp(BWRAP_BIN, argv)
                elif self.isolation_mode == 'proot':
                    # A fully independent, private copy of a root filesystem for THIS
                    # session only. No root/namespaces required, so this is what works even
                    # where kernel containers/namespaces aren't available. Deleting anything
                    # inside it - including things that look like system files - only
                    # destroys this one private copy; the host and other sessions are
                    # untouched. Hardened: we do NOT bind the host's /proc (that would leak
                    # the real host's process list into every session) - only /dev, which is
                    # needed for basic device nodes (/dev/null, /dev/tty, etc). Opt back into
                    # /proc with DARKTERM_PROOT_BIND_PROC=1 if you need `ps`/`top` to work and
                    # accept that trade-off.
                    proot_args = [PROOT_BIN, '--link2symlink', '-0', '-r', session_rootfs]
                    # Bind only the specific device files a shell actually needs, NOT the
                    # whole host /dev directory - binding all of /dev would let a session's
                    # `rm -rf /dev/*` delete real host device nodes shared with every other
                    # session. Each of these is bound read-write individually instead.
                    for dev_node in ('/dev/null', '/dev/zero', '/dev/random',
                                      '/dev/urandom', '/dev/tty', '/dev/full'):
                        target = os.path.join(session_rootfs, dev_node.lstrip('/'))
                        if os.path.exists(dev_node) and os.path.exists(target):
                            proot_args += ['-b', dev_node]
                    if os.environ.get('DARKTERM_PROOT_BIND_PROC', '0') == '1':
                        proot_args += ['-b', '/proc']
                    proot_args += [
                        '-w', '/root',
                        '/usr/bin/env', '-i',
                        'HOME=/root', 'TERM=xterm-256color', f'SESSION_ID={self.session_id}',
                        'PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
                        '/bin/bash', '--rcfile', '/root/.bashrc', '-i'
                    ]
                    for attempt_args in (proot_args, [a for a in proot_args if a != '--link2symlink']):
                        try:
                            os.execvp(PROOT_BIN, attempt_args)
                        except OSError:
                            continue
                    # If we ever reach here, proot itself could not be executed. Fail CLOSED:
                    # never fall back to an unsandboxed shell just because the sandbox broke.
                    sys.stderr.write(
                        "\r\n[DarkTerminal] FATAL: proot isolation could not start for this "
                        "session. Refusing to fall back to an unsandboxed shell.\r\n"
                        "Check that proot is installed and executable, then restart.\r\n")
                    os._exit(1)
                else:
                    os.environ['HOME'] = home_dir
                    os.environ['SESSION_ID'] = self.session_id
                    os.chdir(home_dir)
                    os.execvp('/bin/bash', bash_argv)

                os._exit(0)

            # ── Parent process ──
            self.is_active = True
            print(f"[Session] Started: {self.session_id} (PID {self.pid}, isolation={self.isolation_mode})")
            return True
        except Exception as e:
            print(f"[Session] Error starting {self.session_id}: {e}")
            return False

    def write(self, data, source='ws'):
        """Write raw keystroke/paste data to the pty. Also performs best-effort line
        reconstruction for audit logging + blocking of obviously dangerous *complete* lines
        (this cannot reliably intercept single keystrokes - see is_dangerous_line docs)."""
        if not (self.is_active and self.fd):
            return
        try:
            # Track an assembled line for audit purposes (handles backspace loosely)
            for ch in data:
                if ch in ('\r', '\n'):
                    line = self._line_acc.strip()
                    if line:
                        self._audit(line)
                        self.stats['commands_executed'] += 1
                    self._line_acc = ''
                elif ch == '\x7f':  # backspace
                    self._line_acc = self._line_acc[:-1]
                elif ch.isprintable():
                    self._line_acc += ch

            os.write(self.fd, data.encode())
            self.last_activity = datetime.now()
            self.stats['bytes_transferred'] += len(data)
        except Exception as e:
            print(f"[Session] Write error: {e}")

    def write_command(self, command, source='api'):
        """Used by the REST API, which sends a full command string at once - this CAN
        be reliably checked against the blocklist before it ever reaches the shell."""
        if is_dangerous_line(command):
            self._audit(f"BLOCKED (api): {command}")
            return False
        self.write(command + '\n', source=source)
        return True

    def read(self):
        if self.is_active and self.fd:
            try:
                ready, _, _ = select.select([self.fd], [], [], 0.01)
                if ready:
                    data = os.read(self.fd, 65536)
                    if data:
                        decoded = data.decode('utf-8', errors='replace')
                        with self.buffer_lock:
                            self.output_buffer.append(decoded)
                        self.stats['bytes_transferred'] += len(data)
                        return decoded
            except OSError:
                self.is_active = False
            except Exception as e:
                print(f"[Session] Read error: {e}")
        return None

    def resize(self, rows=24, cols=80):
        if self.is_active and self.fd:
            try:
                winsize = struct.pack('HHHH', rows, cols, 0, 0)
                fcntl.ioctl(self.fd, termios.TIOCSWINSZ, winsize)
            except Exception as e:
                print(f"[Session] Resize error: {e}")

    def kill(self):
        if self.isolation_mode == 'docker' and DOCKER_BIN:
            try:
                subprocess.run([DOCKER_BIN, 'rm', '-f', self.container_name],
                                capture_output=True, timeout=10)
            except Exception as e:
                print(f"[Session] Docker cleanup error: {e}")
        try:
            if self.pid:
                os.kill(self.pid, signal.SIGTERM)
                time.sleep(0.1)
                try:
                    os.kill(self.pid, signal.SIGKILL)
                except OSError:
                    pass
            if self.fd:
                os.close(self.fd)
        except Exception as e:
            print(f"[Session] Kill error: {e}")
        self.is_active = False

    def get_buffered_output(self):
        with self.buffer_lock:
            return ''.join(list(self.output_buffer)[-1000:])

    def to_dict(self, include_sensitive=False):
        data = {
            'session_id': self.session_id,
            'theme': self.theme,
            'created_at': self.created_at.isoformat(),
            'last_activity': self.last_activity.isoformat(),
            'is_active': self.is_active,
            'isolation': self.isolation_mode,
            'sandboxed': self.isolation_mode != 'none',
            'connected_clients': len(self.connected_clients),
            'created_by': self.created_by,
            'stats': self.stats,
            'admin_url': f"/terminal/{self.session_id}",
            'user_url': f"/t/{self.session_id}"
        }
        if include_sensitive:
            data['owner_ip'] = self.owner_ip
        return data

# ═══════════════════════════════════════════════════════════════
# SESSION MANAGEMENT
# ═══════════════════════════════════════════════════════════════

def read_terminal_thread(session_id):
    while True:
        with session_lock:
            session = active_sessions.get(session_id)
        if not session:
            break
        if session.is_active and session.fd:
            try:
                data = session.read()
                if data:
                    emit_data = {'session_id': session_id, 'data': data}
                    try:
                        admin_socketio.emit('output', emit_data, room=session_id)
                        user_socketio.emit('output', emit_data, room=session_id)
                    except Exception:
                        pass
            except Exception:
                pass
        time.sleep(0.005)

def create_new_session(session_id=None, theme="dark", created_by="admin", owner_ip="unknown"):
    if session_id is None:
        session_id = generate_session_id()
    with session_lock:
        if session_id in active_sessions:
            return active_sessions[session_id]
        session = TerminalSession(session_id=session_id, theme=theme, created_by=created_by, owner_ip=owner_ip)
        active_sessions[session_id] = session
    threading.Thread(target=read_terminal_thread, args=(session_id,), daemon=True).start()
    session.start()
    print(f"[V3] Created: {session_id} by {created_by} ({owner_ip})")
    return session

def cleanup_expired_sessions():
    while True:
        try:
            time.sleep(300)
            current_time = datetime.now()
            with session_lock:
                expired = [
                    sid for sid, sess in active_sessions.items()
                    if (current_time - sess.last_activity).total_seconds() > SESSION_IDLE_TIMEOUT_SECONDS
                ]
                for sid in expired:
                    active_sessions[sid].kill()
                    del active_sessions[sid]
                    print(f"[Cleanup] Removed idle session: {sid}")
        except Exception as e:
            print(f"[Cleanup] Error: {e}")

threading.Thread(target=cleanup_expired_sessions, daemon=True).start()

# ═══════════════════════════════════════════════════════════════
# AUTH (admin app only)
# ═══════════════════════════════════════════════════════════════

def _is_locked_out(ip):
    until = login_lock_until.get(ip)
    return bool(until and datetime.now() < until)

def _record_failed_login(ip):
    attempts = login_attempts.setdefault(ip, [])
    attempts.append(datetime.now())
    cutoff = datetime.now() - timedelta(minutes=LOGIN_LOCKOUT_MINUTES)
    attempts[:] = [t for t in attempts if t > cutoff]
    if len(attempts) >= LOGIN_MAX_ATTEMPTS:
        login_lock_until[ip] = datetime.now() + timedelta(minutes=LOGIN_LOCKOUT_MINUTES)

def _clear_failed_logins(ip):
    login_attempts.pop(ip, None)
    login_lock_until.pop(ip, None)

def verify_admin_credentials(username, password, secret_code):
    ok_user = hmac.compare_digest(username or '', ADMIN_USERNAME)
    ok_pass = check_password_hash(ADMIN_PASSWORD_HASH, password or '')
    ok_code = check_password_hash(ADMIN_SECRET_CODE_HASH, secret_code or '')
    return ok_user and ok_pass and ok_code

ADMIN_OPEN_PATHS = {'/login', '/logout'}

@admin_app.before_request
def guard_admin_app():
    if request.path.startswith('/static/'):
        return
    if request.path in ADMIN_OPEN_PATHS:
        return
    if flask_session.get('authenticated'):
        return
    # Programmatic access via API token
    if request.path.startswith('/api/'):
        token = request.headers.get('X-API-Key') or (request.headers.get('Authorization', '').replace('Bearer ', ''))
        if token and hmac.compare_digest(token, ADMIN_API_TOKEN):
            return
        return jsonify({'success': False, 'error': 'Unauthorized - admin login or X-API-Key required', 'code': 401}), 401
    return redirect(url_for('login'))

# ═══════════════════════════════════════════════════════════════
# ADMIN ROUTES
# ═══════════════════════════════════════════════════════════════

@admin_app.route('/login', methods=['GET', 'POST'])
def login():
    if flask_session.get('authenticated'):
        return redirect(url_for('admin_index'))

    ip = get_client_ip(request)
    error = None

    if request.method == 'POST':
        if _is_locked_out(ip):
            remaining = int((login_lock_until[ip] - datetime.now()).total_seconds() // 60) + 1
            error = f"Too many failed attempts. Try again in {remaining} minute(s)."
        else:
            username = request.form.get('username', '')
            password = request.form.get('password', '')
            secret_code = request.form.get('secret_code', '')

            if verify_admin_credentials(username, password, secret_code):
                _clear_failed_logins(ip)
                flask_session.permanent = True
                flask_session['authenticated'] = True
                flask_session['username'] = ADMIN_USERNAME
                flask_session['name'] = ADMIN_NAME
                flask_session['login_at'] = datetime.now().isoformat()
                return redirect(url_for('admin_index'))
            else:
                _record_failed_login(ip)
                error = "Invalid username, password, or secret code."

    return render_template('login.html', version=VERSION, error=error, admin_name=ADMIN_NAME)

@admin_app.route('/logout')
def logout():
    flask_session.clear()
    return redirect(url_for('login'))

@admin_app.route('/')
def admin_index():
    with session_lock:
        sessions = [s.to_dict() for s in active_sessions.values()]
    return render_template('admin_dashboard.html',
                            themes=THEMES, version=VERSION,
                            admin_port=ADMIN_PORT, user_port=USER_PORT,
                            admin_name=flask_session.get('name', ADMIN_NAME),
                            sessions=sessions,
                            sandboxed=(ISOLATION_MODE != 'none'),
                            sandbox_engine=ISOLATION_MODE,
                            running_as_root=RUNNING_AS_ROOT,
                            api_token=ADMIN_API_TOKEN)

@admin_app.route('/terminal/<session_id>')
def admin_terminal(session_id):
    if not session_id.replace('-', '').replace('_', '').isalnum():
        return jsonify({'error': 'Invalid session ID'}), 400
    with session_lock:
        session = active_sessions.get(session_id)
    if not session:
        session = create_new_session(session_id=session_id, created_by='admin', owner_ip=get_client_ip(request))
    return render_template('terminal.html',
                            session_id=session_id, session=session.to_dict(include_sensitive=True),
                            themes=THEMES, is_admin=True, version=VERSION,
                            admin_port=ADMIN_PORT, user_port=USER_PORT)

@admin_app.route('/new')
def admin_new_terminal():
    session = create_new_session(created_by='admin', owner_ip=get_client_ip(request))
    return redirect(url_for('admin_terminal', session_id=session.session_id))

@admin_app.route('/api/v2/sessions/<session_id>/audit', methods=['GET'])
def get_session_audit(session_id):
    with session_lock:
        session = active_sessions.get(session_id)
    if not session:
        return jsonify({'success': False, 'error': 'Not found', 'code': 404}), 404
    log_path = os.path.join(session.storage_path, 'audit.log')
    lines = []
    if os.path.exists(log_path):
        with open(log_path, 'r') as f:
            lines = f.readlines()[-200:]
    return jsonify({'success': True, 'session_id': session_id, 'entries': [l.rstrip() for l in lines]})

@admin_app.route('/static/<path:filename>')
def serve_static_admin(filename):
    return send_from_directory('static', filename)

# ═══════════════════════════════════════════════════════════════
# USER APP ROUTES - deliberately minimal. No API, no docs, no session list.
# ═══════════════════════════════════════════════════════════════

@user_app.route('/')
def user_index():
    return render_template('user_landing.html', version=VERSION)

@user_app.route('/t/<session_id>')
def user_terminal(session_id):
    if not session_id.replace('-', '').replace('_', '').isalnum():
        return render_template('user_error.html', error='Invalid session ID format', version=VERSION), 400

    if is_rate_limited(f"userconnect:{get_client_ip(request)}", max_calls=30, window_seconds=60):
        return render_template('user_error.html', error='Too many attempts. Please slow down.', version=VERSION), 429

    with session_lock:
        session = active_sessions.get(session_id)

    if not session:
        return render_template('user_error.html',
                                error=f'Session "{session_id}" not found or expired', version=VERSION), 404

    return render_template('terminal.html',
                            session_id=session_id, session=session.to_dict(include_sensitive=False),
                            themes=THEMES, is_admin=False, version=VERSION,
                            admin_port=ADMIN_PORT, user_port=USER_PORT)

@user_app.route('/static/<path:filename>')
def serve_static_user(filename):
    return send_from_directory('static', filename)

# ═══════════════════════════════════════════════════════════════
# ADMIN-ONLY REST API v2.1  (mounted on admin_app only - protected by guard_admin_app above)
# ═══════════════════════════════════════════════════════════════

@admin_app.route('/api/v2/info', methods=['GET'])
def api_info():
    base_url = get_base_url(request)
    return jsonify({
        'service': 'DarkTerminal Pro', 'version': VERSION, 'api_version': API_VERSION,
        'authentication': 'Session cookie (browser) or X-API-Key header (programmatic)',
        'sandboxed': (ISOLATION_MODE != 'none'), 'isolation': ISOLATION_MODE,
        'running_as_root': RUNNING_AS_ROOT,
        'endpoints': {
            'info': f'{base_url}/api/v2/info', 'health': f'{base_url}/api/v2/health',
            'sessions': f'{base_url}/api/v2/sessions', 'themes': f'{base_url}/api/v2/themes',
            'stats': f'{base_url}/api/v2/stats'
        },
        'ports': {'admin': ADMIN_PORT, 'user': USER_PORT},
        'timestamp': datetime.now().isoformat(),
        'hostname': socket.gethostname(), 'client_ip': get_client_ip(request)
    })

@admin_app.route('/api/v2/health', methods=['GET'])
def health_check():
    return jsonify({
        'status': 'healthy', 'service': 'DarkTerminal Pro V3', 'version': VERSION,
        'timestamp': datetime.now().isoformat(), 'active_sessions': len(active_sessions),
        'sandboxed': (ISOLATION_MODE != 'none'), 'isolation': ISOLATION_MODE,
        'system': {'python_version': sys.version.split()[0], 'platform': sys.platform, 'hostname': socket.gethostname()}
    })

@admin_app.route('/api/v2/sessions', methods=['GET', 'POST'])
def handle_sessions():
    base_url = get_base_url(request)
    ip = get_client_ip(request)

    if request.method == 'GET':
        with session_lock:
            sessions = [s.to_dict() for s in active_sessions.values()]
        return jsonify({'success': True, 'count': len(sessions), 'sessions': sessions})

    # POST - create
    if is_rate_limited(f"create:{ip}", max_calls=10, window_seconds=60):
        return jsonify({'success': False, 'error': 'Rate limit exceeded, slow down', 'code': 429}), 429

    data = request.get_json(silent=True) or {}
    theme = data.get('theme', 'dark').lower()
    requested_id = data.get('session_id')

    if theme not in THEMES:
        return jsonify({'success': False, 'error': f'Invalid theme. Use one of: {list(THEMES.keys())}', 'code': 400}), 400
    if len(active_sessions) >= admin_app.config['MAX_SESSIONS']:
        return jsonify({'success': False, 'error': 'Max sessions reached', 'code': 429}), 429

    session = create_new_session(session_id=requested_id or generate_session_id(), theme=theme,
                                  created_by='api', owner_ip=ip)

    admin_url = f'{base_url}/terminal/{session.session_id}'
    user_url_host = base_url.rsplit(':', 1)[0] if ':' in base_url.split('//', 1)[-1] else base_url
    return jsonify({
        'success': True,
        'message': 'Terminal session created',
        'session': session.to_dict(),
        'access': {
            'admin_terminal': admin_url,
            'user_terminal_path': f'/t/{session.session_id}',
            'note': f'Share the session ID via the user panel on port {USER_PORT} - not this URL.'
        }
    }), 201

@admin_app.route('/api/v2/sessions/<session_id>', methods=['GET', 'DELETE'])
def handle_session(session_id):
    with session_lock:
        session = active_sessions.get(session_id)
    if not session:
        return jsonify({'success': False, 'error': 'Not found', 'code': 404}), 404

    if request.method == 'GET':
        return jsonify({'success': True, 'session': session.to_dict(include_sensitive=True)})

    session.kill()
    with session_lock:
        active_sessions.pop(session_id, None)
    return jsonify({'success': True, 'message': f'Session {session_id} terminated', 'remaining': len(active_sessions)})

@admin_app.route('/api/v2/sessions/<session_id>/write', methods=['POST'])
def write_to_session(session_id):
    with session_lock:
        session = active_sessions.get(session_id)
    if not session:
        return jsonify({'success': False, 'error': 'Not found', 'code': 404}), 404

    data = request.get_json(silent=True) or {}
    command = data.get('command', '')
    if not command:
        return jsonify({'success': False, 'error': 'Command required', 'code': 400}), 400

    if not session.is_active:
        session.start()

    ok = session.write_command(command, source='api')
    if not ok:
        return jsonify({'success': False, 'error': 'Command blocked by safety policy', 'code': 403}), 403

    return jsonify({'success': True, 'message': 'Command sent', 'length': len(command)})

@admin_app.route('/api/v2/sessions/<session_id>/resize', methods=['POST'])
def resize_session(session_id):
    with session_lock:
        session = active_sessions.get(session_id)
    if not session:
        return jsonify({'success': False, 'error': 'Not found', 'code': 404}), 404
    data = request.get_json(silent=True) or {}
    rows = min(max(int(data.get('rows', 24)), 10), 200)
    cols = min(max(int(data.get('cols', 80)), 20), 500)
    session.resize(rows, cols)
    return jsonify({'success': True, 'size': {'rows': rows, 'cols': cols}})

@admin_app.route('/api/v2/sessions/<session_id>/output', methods=['GET'])
def get_session_output(session_id):
    with session_lock:
        session = active_sessions.get(session_id)
    if not session:
        return jsonify({'success': False, 'error': 'Not found', 'code': 404}), 404
    output = session.get_buffered_output()
    return jsonify({'success': True, 'output': output, 'length': len(output)})

@admin_app.route('/api/v2/themes', methods=['GET'])
def list_themes():
    return jsonify({'success': True, 'themes': {k: {'name': v['name']} for k, v in THEMES.items()},
                     'count': len(THEMES), 'default': 'dark'})

@admin_app.route('/api/v2/stats', methods=['GET'])
def get_stats():
    with session_lock:
        sessions = list(active_sessions.values())
    total_commands = sum(s.stats['commands_executed'] for s in sessions)
    total_bytes = sum(s.stats['bytes_transferred'] for s in sessions)
    return jsonify({
        'success': True,
        'statistics': {
            'active_sessions': len(sessions), 'total_commands': total_commands,
            'total_bytes': total_bytes, 'sandboxed': (ISOLATION_MODE != 'none'), 'isolation': ISOLATION_MODE,
            'uptime_seconds': int(time.time()) - getattr(get_stats, 'start_time', int(time.time()))
        },
        'by_theme': {theme: sum(1 for s in sessions if s.theme == theme) for theme in THEMES.keys()}
    })
get_stats.start_time = int(time.time())

# ═══════════════════════════════════════════════════════════════
# WEBSOCKET HANDLERS
# ═══════════════════════════════════════════════════════════════

@admin_socketio.on('connect')
def admin_ws_connect():
    if not flask_session.get('authenticated'):
        print(f"[WS-Admin] Rejected unauthenticated connect: {request.sid}")
        return False
    emit('connected', {'message': 'Connected to DarkTerminal Pro V3 (admin)', 'version': VERSION})

@user_socketio.on('connect')
def user_ws_connect():
    emit('connected', {'message': 'Connected to DarkTerminal Pro V3', 'version': VERSION})

@admin_socketio.on('disconnect')
def admin_ws_disconnect():
    pass

@user_socketio.on('disconnect')
def user_ws_disconnect():
    pass

@admin_socketio.on('join_terminal')
@user_socketio.on('join_terminal')
def ws_join_terminal(data):
    session_id = data.get('session_id')
    if not session_id:
        return
    join_room(session_id)
    with session_lock:
        session = active_sessions.get(session_id)
    if session:
        session.connected_clients.add(request.sid)
        buffered = session.get_buffered_output()
        if buffered:
            emit('output', {'session_id': session_id, 'data': buffered})
        emit('joined', {'session_id': session_id, 'clients': len(session.connected_clients)})
    else:
        emit('error', {'message': f'Session {session_id} not found'})

@admin_socketio.on('leave_terminal')
@user_socketio.on('leave_terminal')
def ws_leave_terminal(data):
    session_id = data.get('session_id')
    if session_id:
        leave_room(session_id)
        with session_lock:
            session = active_sessions.get(session_id)
        if session:
            session.connected_clients.discard(request.sid)

@admin_socketio.on('input')
@user_socketio.on('input')
def ws_input(data):
    session_id = data.get('session_id')
    input_data = data.get('data', '')
    if not session_id:
        return
    with session_lock:
        session = active_sessions.get(session_id)
    if session and session.is_active:
        session.write(input_data, source='ws')

@admin_socketio.on('resize')
@user_socketio.on('resize')
def ws_resize(data):
    session_id = data.get('session_id')
    with session_lock:
        session = active_sessions.get(session_id)
    if session:
        session.resize(data.get('rows', 24), data.get('cols', 80))

@admin_socketio.on('request_history')
@user_socketio.on('request_history')
def ws_request_history(data):
    session_id = data.get('session_id')
    with session_lock:
        session = active_sessions.get(session_id)
    if session:
        emit('history_data', {'session_id': session_id, 'data': session.get_buffered_output()})

# ═══════════════════════════════════════════════════════════════
# ERROR HANDLERS
# ═══════════════════════════════════════════════════════════════

@admin_app.errorhandler(404)
def admin_404(e):
    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'error': 'Not found', 'code': 404}), 404
    return render_template('page_404.html', version=VERSION), 404

@admin_app.errorhandler(500)
def admin_500(e):
    admin_app.logger.error(f'Error: {e}')
    if request.path.startswith('/api/'):
        return jsonify({'success': False, 'error': 'Server error', 'code': 500}), 500
    return render_template('page_500.html', version=VERSION), 500

@user_app.errorhandler(404)
def user_404(e):
    return render_template('page_404.html', version=VERSION), 404

@user_app.errorhandler(500)
def user_500(e):
    user_app.logger.error(f'Error: {e}')
    return render_template('page_500.html', version=VERSION), 500

# ═══════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════

def run_admin(port, host):
    print(f"\n{'='*60}\nADMIN PANEL: http://{host}:{port}  (login required)\n{'='*60}\n")
    admin_socketio.run(app=admin_app, host=host, port=port, debug=False, allow_unsafe_werkzeug=True)

def run_user(port, host):
    print(f"\n{'='*60}\nUSER PANEL:  http://{host}:{port}  (session ID = access)\n{'='*60}\n")
    user_socketio.run(app=user_app, host=host, port=port, debug=False, allow_unsafe_werkzeug=True)

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser(description='DarkTerminal Pro V3.1 - Beast Edition (Secured)')
    parser.add_argument('--admin-port', '-ap', type=int, default=8080)
    parser.add_argument('--user-port', '-up', type=int, default=9090)
    parser.add_argument('--host', type=str, default='0.0.0.0')
    parser.add_argument('--max-sessions', type=int, default=100)
    parser.add_argument('--admin-only', action='store_true')
    args = parser.parse_args()

    ADMIN_PORT = args.admin_port
    USER_PORT = args.user_port
    HOST = args.host
    admin_app.config['MAX_SESSIONS'] = args.max_sessions
    user_app.config['MAX_SESSIONS'] = args.max_sessions

    print(f'''
╔═══════════════════════════════════════════════════════════════════════╗
║  DARKTERMINAL PRO  -  V E R S I O N   3 . 1   ( S E C U R E D )        ║
╠═══════════════════════════════════════════════════════════════════════╣
║  Admin Panel : http://{HOST}:{ADMIN_PORT}  (login required)
║  User Panel  : http://{HOST}:{USER_PORT}  (session ID only, no API)
║  Login       : {ADMIN_USERNAME} / (password) / (secret code)
║  Isolation   : {ISOLATION_MODE.upper()}{' - per-session containers, private IPs, no shared FS' if ISOLATION_MODE == 'docker' else (' - install Docker for full per-session container isolation' if ISOLATION_MODE == 'none' else ' - namespace-level, host filesystem still partially visible; Docker recommended')}
╠═══════════════════════════════════════════════════════════════════════╣
║  ADMIN API TOKEN (for curl/API access, shown once per start):          ║
║  {ADMIN_API_TOKEN}
╚═══════════════════════════════════════════════════════════════════════╝
''')

    admin_thread = threading.Thread(target=run_admin, args=(args.admin_port, args.host), daemon=True)
    admin_thread.start()

    if not args.admin_only:
        time.sleep(1)
        user_thread = threading.Thread(target=run_user, args=(args.user_port, args.host), daemon=True)
        user_thread.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("\n[V3] Shutting down...")
        with session_lock:
            for session in active_sessions.values():
                session.kill()
            active_sessions.clear()
        print("[V3] Goodbye!")
        sys.exit(0)
