#!/bin/bash
# DarkTerminal Pro V3.1 - Beast Edition (Secured) — Interactive Launcher

set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'; BOLD='\033[1m'

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

echo ""
echo -e "${CYAN}════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}  DARKTERMINAL PRO — V3.1 (Secured)${NC}"
echo -e "${CYAN}════════════════════════════════════════════════════════${NC}"
echo ""

if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[ERROR] Python 3 is required but not installed.${NC}"
    exit 1
fi
if ! command -v pip3 &> /dev/null; then
    echo -e "${RED}[ERROR] pip3 is required but not installed.${NC}"
    exit 1
fi

echo -e "${BLUE}[INFO] Checking dependencies...${NC}"
if ! python3 -c "import flask, flask_socketio, flask_cors" &> /dev/null; then
    echo -e "${YELLOW}[INFO] Installing Python dependencies...${NC}"
    pip3 install -r requirements.txt --quiet --break-system-packages 2>/dev/null || pip3 install -r requirements.txt --quiet
    echo -e "${GREEN}[OK] Dependencies installed.${NC}"
else
    echo -e "${GREEN}[OK] Dependencies already installed.${NC}"
fi

if command -v firejail &> /dev/null; then
    echo -e "${GREEN}[OK] firejail found - sessions will be OS-sandboxed.${NC}"
elif command -v bwrap &> /dev/null; then
    echo -e "${GREEN}[OK] bwrap found - sessions will be OS-sandboxed.${NC}"
elif command -v proot &> /dev/null; then
    if [ -f "rootfs-template/bin/sh" ]; then
        echo -e "${GREEN}[OK] proot + rootfs template found - sessions get private isolated filesystems.${NC}"
    else
        echo -e "${YELLOW}[WARN] proot is installed but no rootfs template exists yet.${NC}"
        echo -e "${YELLOW}       Run: ./setup_rootfs.sh   (one-time, builds the private-session template)${NC}"
    fi
else
    echo -e "${YELLOW}[WARN] No isolation engine found (docker/firejail/bwrap/proot).${NC}"
    echo -e "${YELLOW}       On Termux/Android: pkg install proot && ./setup_rootfs.sh${NC}"
    echo -e "${YELLOW}       Sessions will run unsandboxed until one of these is set up.${NC}"
fi

mkdir -p sessions logs static/css static/js templates

echo ""
echo -e "${BOLD}${CYAN}═══════════════ PORT CONFIGURATION ═══════════════${NC}"
echo ""
echo -ne "${GREEN}[?]${NC} ADMIN PANEL port [8080]: "
read ADMIN_PORT_INPUT
ADMIN_PORT=${ADMIN_PORT_INPUT:-8080}

echo -ne "${GREEN}[?]${NC} USER PANEL port [9090]: "
read USER_PORT_INPUT
USER_PORT=${USER_PORT_INPUT:-9090}

echo -ne "${GREEN}[?]${NC} Host binding [0.0.0.0]: "
read HOST_INPUT
HOST=${HOST_INPUT:-0.0.0.0}

if [ "$ADMIN_PORT" = "$USER_PORT" ]; then
    echo -e "${RED}[ERROR] Admin and User ports must be different!${NC}"
    exit 1
fi

echo ""
echo -e "${BLUE}[CONFIG] Admin Panel:  ${GREEN}http://${HOST}:${ADMIN_PORT}${NC}  (login required)"
echo -e "${BLUE}[CONFIG] User Panel:   ${GREEN}http://${HOST}:${USER_PORT}${NC}  (session ID only)"
echo ""
echo -e "${YELLOW}[INFO] Starting servers... Press Ctrl+C to stop${NC}"
echo ""

python3 darkterminal_v3.py \
    --admin-port "$ADMIN_PORT" \
    --user-port "$USER_PORT" \
    --host "$HOST" \
    --max-sessions 100
