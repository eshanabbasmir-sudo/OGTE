/* DarkTerminal Pro — User landing page.
   Kept intentionally minimal: connect-by-session-ID only. No API calls, no docs links. */

document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('access-form');
  const input = document.getElementById('session-input');
  const messages = document.getElementById('message-container');

  function showMessage(text, type) {
    messages.innerHTML = '';
    const el = document.createElement('div');
    el.className = 'alert ' + (type === 'error' ? 'alert-error' : 'alert-success');
    const iconId = type === 'error' ? 'i-close' : 'i-check';
    el.innerHTML = `<svg class="icon"><use href="#${iconId}"/></svg><span>${text}</span>`;
    messages.appendChild(el);
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const sessionId = input.value.trim();

    if (!sessionId) {
      showMessage('Please enter a session ID', 'error');
      input.classList.add('error');
      setTimeout(() => input.classList.remove('error'), 400);
      return;
    }

    if (!/^[a-zA-Z0-9_-]{6,}$/.test(sessionId)) {
      showMessage('That doesn\u2019t look like a valid session ID', 'error');
      input.classList.add('error');
      setTimeout(() => input.classList.remove('error'), 400);
      return;
    }

    showMessage('Connecting…', 'success');
    window.location.href = `/t/${encodeURIComponent(sessionId)}`;
  });

  input.focus();
});
