/* DarkTerminal Pro — Terminal view. Real-time WebSocket terminal via xterm.js. */

let config = {};
try {
  config = JSON.parse(document.getElementById('config')?.textContent || '{}');
} catch (e) {
  console.error('[Terminal] Failed to parse config:', e);
}

const SESSION_ID = config.sessionId || '';
const IS_ADMIN = config.isAdmin || false;

const THEMES = {
  dark: { background: '#0a0a0f', foreground: '#00ff88', cursor: '#00ff88', cursorAccent: '#0a0a0f', selectionBackground: 'rgba(0, 255, 136, 0.3)', selectionForeground: '#ffffff' },
  matrix: { background: '#000000', foreground: '#00ff41', cursor: '#00ff41', cursorAccent: '#000000', selectionBackground: 'rgba(0, 255, 65, 0.3)', selectionForeground: '#ffffff' },
  cyberpunk: { background: '#1a0a2e', foreground: '#f0abfc', cursor: '#f0abfc', cursorAccent: '#1a0a2e', selectionBackground: 'rgba(240, 171, 252, 0.3)', selectionForeground: '#ffffff' },
  hacker: { background: '#0c0c0c', foreground: '#00ff00', cursor: '#00ff00', cursorAccent: '#0c0c0c', selectionBackground: 'rgba(0, 255, 0, 0.3)', selectionForeground: '#ffffff' },
  ocean: { background: '#0a1628', foreground: '#00d4ff', cursor: '#00d4ff', cursorAccent: '#0a1628', selectionBackground: 'rgba(0, 212, 255, 0.3)', selectionForeground: '#ffffff' },
  solarized: { background: '#002b36', foreground: '#839496', cursor: '#839496', cursorAccent: '#002b36', selectionBackground: 'rgba(131, 148, 150, 0.3)', selectionForeground: '#ffffff' },
  monokai: { background: '#272822', foreground: '#f8f8f2', cursor: '#f8f8f2', cursorAccent: '#272822', selectionBackground: 'rgba(248, 248, 242, 0.3)', selectionForeground: '#272822' },
  nord: { background: '#2e3440', foreground: '#eceff4', cursor: '#eceff4', cursorAccent: '#2e3440', selectionBackground: 'rgba(236, 239, 244, 0.2)', selectionForeground: '#2e3440' }
};

let term = null;
let fitAddon = null;
let socket = null;
let currentTheme = config.initialTheme && THEMES[config.initialTheme] ? config.initialTheme : 'dark';

function initTerminal() {
  const container = document.getElementById('terminal-container');
  if (!container) return;

  term = new Terminal({
    theme: THEMES[currentTheme],
    cursorBlink: true,
    cursorStyle: 'block',
    fontSize: 14,
    fontFamily: '"JetBrains Mono", "Fira Code", "SF Mono", Consolas, monospace',
    lineHeight: 1.25,
    scrollback: 10000,
    allowTransparency: true,
    convertEol: true,
    tabStopWidth: 4
  });

  fitAddon = new FitAddon.FitAddon();
  term.loadAddon(fitAddon);
  term.open(container);
  fitToFit();

  window.addEventListener('resize', () => {
    fitToFit();
    sendResize();
  });

  term.onData((data) => {
    if (socket && socket.connected) {
      socket.emit('input', { session_id: SESSION_ID, data });
    }
  });

  container.addEventListener('click', () => term.focus());
  setTimeout(() => term.focus(), 400);
}

function fitToFit() {
  if (!fitAddon) return;
  try { fitAddon.fit(); } catch (e) { /* container not visible yet */ }
}

function sendResize() {
  if (socket && socket.connected && term) {
    const { rows, cols } = term;
    socket.emit('resize', { session_id: SESSION_ID, rows, cols });
  }
}

function connectWebSocket() {
  const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  const host = window.location.host;

  socket = io(`${protocol}//${host}`, {
    transports: ['websocket', 'polling'],
    reconnection: true,
    reconnectionAttempts: Infinity,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
    withCredentials: true
  });

  socket.on('connect', () => {
    updateConnectionStatus(true);
    socket.emit('join_terminal', { session_id: SESSION_ID });
    setTimeout(() => socket.emit('request_history', { session_id: SESSION_ID }), 400);
    sendResize();
    term.focus();
  });

  socket.on('disconnect', () => updateConnectionStatus(false));

  socket.on('reconnect', () => {
    showTerminalMessage('\r\n\x1b[32m✓ Reconnected to server\x1b[0m\r\n');
  });

  socket.on('joined', (data) => updateClientCount(data.clients));

  socket.on('output', (data) => {
    if (data.data && term) term.write(data.data);
  });

  socket.on('history_data', (data) => {
    if (data.data && term) term.write(data.data);
  });

  socket.on('error', (data) => {
    showTerminalMessage(`\r\n\x1b[31mError: ${data.message}\x1b[0m\r\n`);
  });

  socket.on('connect_error', () => updateConnectionStatus(false));
}

function updateConnectionStatus(connected) {
  const el = document.getElementById('connection-status');
  const win = document.getElementById('terminal-window');
  const overlay = document.getElementById('boot-overlay');
  if (!el) return;
  if (connected) {
    el.innerHTML = '<span class="dot connected">●</span> CONNECTED';
    el.className = 'status-item connection-status connected';
    win?.classList.add('is-connected');
    if (overlay && !overlay.classList.contains('fade-out')) {
      overlay.classList.add('fade-out');
      setTimeout(() => overlay.remove(), 450);
    }
  } else {
    el.innerHTML = '<span class="dot disconnected">●</span> DISCONNECTED';
    el.className = 'status-item connection-status disconnected';
    win?.classList.remove('is-connected');
  }
}

function updateClientCount(count) {
  const el = document.getElementById('client-count');
  if (el) el.textContent = `Clients: ${count}`;
}

function showTerminalMessage(message) {
  if (term) term.write(message);
}

function changeTheme() {
  document.getElementById('theme-picker')?.classList.toggle('hidden');
}

function setTheme(themeName) {
  if (!THEMES[themeName]) return;
  currentTheme = themeName;
  if (term) term.options.theme = THEMES[themeName];
  document.getElementById('theme-name').textContent = themeName;
  document.querySelectorAll('.theme-option').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.theme === themeName);
  });
  document.getElementById('theme-picker')?.classList.add('hidden');
}

function toggleFullscreen() {
  document.body.classList.toggle('fullscreen');
  if (document.fullscreenElement) {
    document.exitFullscreen();
  } else {
    document.documentElement.requestFullscreen().catch(() => {});
  }
  setTimeout(fitToFit, 100);
}

function toggleSessionInfo() {
  document.getElementById('session-info')?.classList.toggle('hidden');
}

document.addEventListener('keydown', (e) => {
  if (document.activeElement && document.activeElement.tagName === 'INPUT') return;
  if (e.key === 'F11') { e.preventDefault(); toggleFullscreen(); }
});

document.addEventListener('DOMContentLoaded', () => {
  initTerminal();
  connectWebSocket();
});
