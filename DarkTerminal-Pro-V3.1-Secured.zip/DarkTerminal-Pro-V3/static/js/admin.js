/* DarkTerminal Pro — Admin dashboard */

const initData = JSON.parse(document.getElementById('init-data')?.textContent || '{}');

// ── Toasts ─────────────────────────────────────────────────────

function toast(message, type = 'success') {
  const stack = document.getElementById('toast-stack');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  const iconId = type === 'error' ? 'i-close' : 'i-check';
  el.innerHTML = `<span style="display:flex;align-items:center;gap:8px;"><svg class="icon"><use href="#${iconId}"/></svg><span>${message}</span></span>`;
  stack.appendChild(el);
  setTimeout(() => el.remove(), 3800);
}

// ── Mobile sidebar drawer ───────────────────────────────────────

const menuToggle = document.getElementById('menu-toggle');
const sidebar = document.getElementById('sidebar');
const overlay = document.getElementById('sidebar-overlay');

function closeSidebar() {
  sidebar?.classList.remove('open');
  overlay?.classList.remove('show');
}
menuToggle?.addEventListener('click', () => {
  sidebar?.classList.toggle('open');
  overlay?.classList.toggle('show');
});
overlay?.addEventListener('click', closeSidebar);

// ── Tabs ───────────────────────────────────────────────────────

document.querySelectorAll('.side-link[data-tab]').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.side-link[data-tab]').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
    document.getElementById(`tab-${btn.dataset.tab}`)?.classList.remove('hidden');
    if (btn.dataset.tab === 'sessions') loadSessions();
    closeSidebar();
  });
});

// ── API helper (same-origin, cookie auth already attached) ─────

async function api(method, url, body) {
  const res = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    credentials: 'same-origin',
    body: body ? JSON.stringify(body) : undefined
  });
  let data;
  try { data = await res.json(); } catch (e) { data = { success: false, error: 'Invalid response' }; }
  return { ok: res.ok, status: res.status, data };
}

function fmtBytes(n) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

function fmtUptime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${h}h ${m}m`;
}

// ── Stats polling ────────────────────────────────────────────

async function refreshStats() {
  const { ok, data } = await api('GET', '/api/v2/stats');
  if (!ok) return;
  document.getElementById('stat-sessions').textContent = data.statistics.active_sessions;
  document.getElementById('stat-commands').textContent = data.statistics.total_commands;
  document.getElementById('stat-bytes').textContent = fmtBytes(data.statistics.total_bytes);
  document.getElementById('stat-uptime').textContent = fmtUptime(data.statistics.uptime_seconds);
}

// ── Sessions table ──────────────────────────────────────────

async function loadSessions() {
  const wrap = document.getElementById('sessions-table-wrap');
  const { ok, data } = await api('GET', '/api/v2/sessions');
  if (!ok) {
    wrap.innerHTML = `<div class="empty-state"><svg class="icon icon-xl" style="color:var(--danger);margin-bottom:10px;"><use href="#i-alert"/></svg><div>Failed to load sessions</div></div>`;
    return;
  }
  if (!data.sessions.length) {
    wrap.innerHTML = `<div class="empty-state"><svg class="icon icon-xl" style="color:var(--text-2);margin-bottom:10px;"><use href="#i-terminal"/></svg><div>No active sessions yet — create one to get started.</div></div>`;
    return;
  }

  const rows = data.sessions.map(s => `
    <tr>
      <td><code>${s.session_id.substring(0, 16)}…</code></td>
      <td>${s.theme}</td>
      <td>${s.created_by}</td>
      <td>${s.is_active ? '<span class="pill pill-live"><span class="pill-dot"></span>Active</span>' : '<span class="pill">Stopped</span>'}</td>
      <td>${s.connected_clients}</td>
      <td>${s.stats.commands_executed}</td>
      <td>
        <div class="row-actions">
          <a class="btn btn-sm" href="/terminal/${s.session_id}" target="_blank">Open</a>
          <button class="btn btn-sm btn-danger" data-kill="${s.session_id}">Kill</button>
        </div>
      </td>
    </tr>
  `).join('');

  wrap.innerHTML = `
    <table class="data-table">
      <thead><tr><th>Session</th><th>Theme</th><th>Created by</th><th>Status</th><th>Clients</th><th>Commands</th><th>Actions</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  `;

  wrap.querySelectorAll('[data-kill]').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (!confirm('Terminate this session? This cannot be undone.')) return;
      const id = btn.dataset.kill;
      const { ok } = await api('DELETE', `/api/v2/sessions/${id}`);
      if (ok) { toast('Session terminated', 'success'); loadSessions(); refreshStats(); }
      else toast('Failed to terminate session', 'error');
    });
  });
}

async function createSession() {
  const { ok, data } = await api('POST', '/api/v2/sessions', { theme: 'dark' });
  if (ok) {
    toast('Terminal created', 'success');
    window.open(`/terminal/${data.session.session_id}`, '_blank');
    loadSessions();
    refreshStats();
  } else {
    toast(data.error || 'Failed to create session', 'error');
  }
}

document.getElementById('quick-create')?.addEventListener('click', createSession);
document.getElementById('create-session-btn')?.addEventListener('click', createSession);

// ── API console ──────────────────────────────────────────────

function syntaxHighlight(json) {
  const escaped = json
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  return escaped.replace(
    /("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false)\b|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
    (match) => {
      let cls = 'json-number';
      if (/^"/.test(match)) cls = /:$/.test(match) ? 'json-key' : 'json-string';
      else if (/true|false/.test(match)) cls = 'json-bool';
      else if (/null/.test(match)) cls = 'json-null';
      return `<span class="${cls}">${match}</span>`;
    }
  );
}

document.querySelectorAll('.endpoint-btn').forEach(btn => {
  btn.addEventListener('click', async () => {
    const method = btn.dataset.method;
    const url = btn.dataset.url;
    const body = btn.dataset.body ? JSON.parse(btn.dataset.body) : undefined;
    const out = document.getElementById('json-output');
    out.textContent = 'Loading…';
    const { status, data } = await api(method, url, body);
    out.innerHTML = `<div class="muted" style="margin-bottom:8px;">${method} ${url} → ${status}</div>` +
      syntaxHighlight(JSON.stringify(data, null, 2));
    if (url === '/api/v2/sessions' && method === 'POST') { loadSessions(); refreshStats(); }
  });
});

document.getElementById('copy-token-btn')?.addEventListener('click', () => {
  const text = document.getElementById('api-token-value').textContent;
  navigator.clipboard.writeText(text).then(() => toast('Token copied', 'success'))
    .catch(() => toast('Could not copy — select manually', 'error'));
});

// ── Init ─────────────────────────────────────────────────────

refreshStats();
setInterval(refreshStats, 5000);
