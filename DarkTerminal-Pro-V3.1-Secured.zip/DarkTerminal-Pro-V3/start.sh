#!/bin/bash
# DarkTerminal Pro V3.1 - Quick Start
# Admin panel now requires login. Default ports: 8080 (admin), 9090 (user).

echo "Starting DarkTerminal Pro V3.1 (Secured)..."
echo ""

cd "$(dirname "$0")"

pip3 install -q flask flask-socketio flask-cors eventlet --break-system-packages 2>/dev/null \
  || pip3 install -q flask flask-socketio flask-cors eventlet 2>/dev/null || true

if ! command -v firejail &> /dev/null && ! command -v bwrap &> /dev/null; then
  if command -v proot &> /dev/null && [ -f "rootfs-template/bin/sh" ]; then
    echo "✓ Using proot for per-session isolation (rootfs template found)."
  elif command -v proot &> /dev/null; then
    echo "⚠  proot is installed but no rootfs template exists — run ./setup_rootfs.sh first."
  else
    echo "⚠  No isolation engine (docker/firejail/bwrap/proot) found - sessions will NOT be isolated."
    echo "   On Termux/Android: pkg install proot && ./setup_rootfs.sh"
  fi
  echo ""
fi

chmod +x setup_rootfs.sh 2>/dev/null || true

python3 darkterminal_v3.py --admin-port 8080 --user-port 9090 --host 0.0.0.0
